"""Applies the content + data-bridge changes to the original Attest page.
Every replacement must match exactly once, so nothing is changed by accident.
Usage: python3 patch_frontend.py original.html output.html"""
import sys

src = open(sys.argv[1], encoding="utf-8").read()
n_edits = 0

def rep(old, new):
    global src, n_edits
    assert src.count(old) == 1, f"expected exactly 1 match, found {src.count(old)} for: {old[:70]!r}"
    src = src.replace(old, new)
    n_edits += 1

PS = "2026262"
FULL = "Integrated AICTE Approval Workflow Automation, Compliance Monitoring and Alert Management System"

# ------------------------------------------------------------------ copy: head and sphere
rep("<title>Attest – Application verification for AICTE reviewers</title>",
    "<title>Attest – Integrated AICTE Approval Workflow, Compliance Monitoring and Alert Management</title>")
rep('<span class="inner"><span style="--i:0">Check</span> <span style="--i:1">every</span> <span style="--i:2">application</span> <span style="--i:3">before</span> <span style="--i:4">a</span> <span style="--i:5">person</span> <span style="--i:6">has</span> <span style="--i:7">to.</span></span>',
    '<span class="inner"><span style="--i:0">Every</span> <span style="--i:1">approval,</span> <span style="--i:2">on</span> <span style="--i:3">time</span> <span style="--i:4">and</span> <span style="--i:5">on</span> <span style="--i:6">record.</span></span>')
rep("<p>Attest reads every document a college submits to AICTE, compares them field by field, tests them against the rules, and hands the reviewer a report with the evidence attached.</p></div>",
    "<p>Attest tracks every application from submission to decision, tests each institution against the approval norms, and alerts the competent officer before a deadline or a compliance lapse becomes a delay.</p></div>")
rep("PS SIH26261 · AICTE</div>", f"PS {PS} · AICTE</div>")

# ------------------------------------------------------------------ copy: hero
rep('<nav><a href="#demo">Live check</a><a href="#how">How it works</a><a href="#trust">Reviewer control</a><a href="#demo">Try it</a></nav>',
    '<nav><a href="#demo">Live scrutiny</a><a href="#how">Workflow</a><a href="#trust">Officer control</a><a href="#demo">Try it</a></nav>')
rep("<h1>Check every application before a person has to.</h1>", "<h1>Every approval, on time and on record.</h1>")
rep('<p class="lead">Attest reads the documents a college submits to AICTE, compares them field by field, tests them against the rules, and hands the reviewer a report with the evidence attached.</p>',
    '<p class="lead">Attest moves every AICTE institutional approval through one auditable workflow: scrutiny, expert review and decision, with compliance monitored continuously and alerts raised before a statutory deadline is missed.</p>')
rep(">Run a sample check</button>", ">Run a sample scrutiny</button>")
rep(">See how it works</button>", ">View the workflow</button>")
rep('<h3 id="it">Five layers, one report</h3><p id="ip">Hover a layer. Each one is a stage of the pipeline, stacked so a reviewer can see how a verdict was built.</p>',
    '<h3 id="it">Five stages, one record</h3><p id="ip">Hover a stage. Each one is a step of the approval workflow, stacked so an officer can see how a decision was built.</p>')

# ------------------------------------------------------------------ copy: live demo
rep("<b>Case 4839</b> · Sample Institute of Technology (synthetic data)", "<b>Application 4839</b> · Sample Institute of Technology (synthetic data)")
rep('<button class="btn" id="run">Run verification</button>', '<button class="btn" id="run">Run scrutiny</button>')
rep("Three synthetic documents are loaded. Run the check to compare them.", "Three synthetic documents are loaded. Run the scrutiny to compare them against the checklist.")
rep("<div>Readiness score</div>", "<div>Compliance score</div>")

# ------------------------------------------------------------------ copy: problem statement
rep("<h2>What PS SIH26261 asks for</h2>", f"<h2>What PS {PS} asks for</h2>")
rep("Organisation: AICTE · Category: Software. Attest answers the three parts of the problem statement.",
    "Organisation: AICTE · Category: Software. Attest addresses the three components of the problem statement.")
rep("<div><h3>Application validation</h3><p>Checks that an application is complete and that its details agree across documents.</p></div>",
    "<div><h3>Approval workflow automation</h3><p>Moves each application through submission, scrutiny, expert review and decision, with defined roles and statutory timelines.</p></div>")
rep("<div><h3>Document authentication</h3><p>Flags possible alterations and inconsistent metadata for a person to examine, without claiming proof of fraud.</p></div>",
    "<div><h3>Compliance monitoring</h3><p>Tests institutions against a configurable rule set, before approval and continuously after it, and shows the evidence behind every result.</p></div>")
rep("<div><h3>Regulatory compliance verification</h3><p>Applies a configurable rule set and shows the evidence behind each result.</p></div>",
    "<div><h3>Alert management</h3><p>Raises alerts for overdue stages and compliance lapses, and escalates unattended alerts to the next level of authority.</p></div>")

# ------------------------------------------------------------------ copy: how it works
rep("<h2>From upload to report in five steps</h2>", "<h2>From submission to monitoring in five steps</h2>")
rep('<p class="lead">Each step is visible to the reviewer, so nothing is a black box.</p>',
    '<p class="lead">Each step is visible to the officer and recorded, so nothing is a black box.</p>')
rep('<b>1</b><h3>Upload</h3><p>PDFs and scanned certificates.</p><span class="hv">Accepts PDF, JPG and PNG. Each file is stored with a hash so later edits are detectable.</span>',
    '<b>1</b><h3>Submit</h3><p>Institution files the application.</p><span class="hv">Accepts PDF, JPG and PNG. Each file is stored with a SHA-256 hash so later edits are detectable.</span>')
rep('<b>2</b><h3>Extract</h3><p>OCR reads names, dates, numbers.</p><span class="hv">PyMuPDF for digital PDFs, PaddleOCR for scans. Every value keeps its page and position.</span>',
    '<b>2</b><h3>Scrutinise</h3><p>Documents are read and cross-checked.</p><span class="hv">Text is extracted from every document and each field is compared across files. Every value keeps its page.</span>')
rep('<b>3</b><h3>Compare</h3><p>Fields are matched across documents.</p><span class="hv">Names and numbers are normalised, then compared. Disagreements show both values side by side.</span>',
    '<b>3</b><h3>Review</h3><p>Officers and experts examine the evidence.</p><span class="hv">Disagreements show both values side by side. Every stage runs against a statutory timeline.</span>')
rep('<b>4</b><h3>Check rules</h3><p>A configurable rule set is applied.</p><span class="hv">Rules are plain configuration, so reviewers can change a threshold without touching code.</span>',
    '<b>4</b><h3>Decide</h3><p>Decision is issued with reasons.</p><span class="hv">Approval is blocked while a mandatory document is missing, unless an authorised officer records an override.</span>')
rep('<b>5</b><h3>Report</h3><p>Findings come with their evidence.</p><span class="hv">Passed checks, warnings, evidence and a suggested next action, ready for the reviewer.</span>',
    '<b>5</b><h3>Monitor</h3><p>Compliance is watched after approval.</p><span class="hv">Rules run on a schedule. Expiring certificates and breaches raise alerts that escalate if no one acts.</span>')

# ------------------------------------------------------------------ copy: officer control, footer, menu, splash
rep("<h2>The reviewer decides</h2>", "<h2>The competent authority decides</h2>")
rep('<p class="lead">Attest recommends. An authorised reviewer approves, rejects, or asks for corrections, and every decision is recorded with a reason.</p>',
    '<p class="lead">Attest recommends. An authorised officer approves, rejects, or requests corrections, and every decision is recorded with a reason in a tamper-evident audit trail.</p>')
rep("<span>Case 4839 opened</span><span>System</span>", "<span>Application 4839 received</span><span>System</span>")
rep("Built for Smart India Hackathon 2026 · PS SIH26261 · All documents shown are synthetic samples.",
    f"Built for Smart India Hackathon 2026 · PS {PS} · Prototype for demonstration, not an official AICTE portal. All data shown is synthetic.")
rep('<a href="#" data-g>The Layers</a><a href="#demo">Live check</a><a href="#how">How it works</a><a href="#trust">Reviewer control</a>',
    '<a href="#" data-g>The Stages</a><a href="#demo">Live scrutiny</a><a href="#how">Workflow</a><a href="#trust">Officer control</a>')
rep("Smart India Hackathon 2026<br>PS SIH26261 · AI-Powered Application Validation, Document Authentication and Regulatory Compliance Verification",
    f"Smart India Hackathon 2026<br>PS {PS} · {FULL}")
rep("Smart India Hackathon 2026 · SIH26261</div>", f"Smart India Hackathon 2026 · PS {PS}</div>")

# ------------------------------------------------------------------ JS: sphere + layers text
rep('const L=[["Upload","Documents enter the system","The applicant submits the form and supporting files. Each file is fingerprinted on arrival."],["Extract","OCR turns pages into fields","Names, dates, registration numbers and counts are read and tied to their page."],["Compare","Fields are matched across files","The same fact is checked in every document. Conflicts are listed with both values."],["Rules","Configured checks are applied","Each regulatory rule returns pass, review or missing, with the evidence it used."],["Report","Evidence-backed summary","Everything the reviewer needs in one place, with a suggested next action."]];',
    'const L=[["Submit","Application enters the system","The institution files the form and supporting documents. Each file is fingerprinted on arrival."],["Scrutinise","Documents are read and cross-checked","Names, dates, registration numbers and counts are read, tied to their page, and compared across files."],["Review","Officers examine the evidence","Conflicts are listed with both values. Each stage runs against a statutory timeline."],["Decide","Decision is issued with reasons","Approval, correction request or rejection, recorded with a reason and the officer\'s identity."],["Monitor","Compliance is watched continuously","Rules run on a schedule and alerts escalate to the next authority if nobody acts."]];')
rep('["Upload","Step 1 · Application intake","Accepts PDF, JPG and PNG. Each file is stored with a hash so later edits are detectable.",0,"Done"],\n["Extract","Step 2 · Application validation","PyMuPDF for digital PDFs, PaddleOCR for scans. Every value keeps its page and position.",0,"Done"],\n["Compare","Step 3 · Application validation","Names and numbers are normalised, then compared. Disagreements show both values side by side.",0,"Done"],\n["Check rules","Step 4 · Regulatory compliance","Rules are plain configuration, so reviewers can change a threshold without touching code.",0,"Done"],\n["Report","Step 5 · Reviewer report","Passed checks, warnings, evidence and a suggested next action, ready for the reviewer.",0,"Done"],',
    '["Submit","Step 1 · Application intake","Accepts PDF, JPG and PNG. Each file is stored with a hash so later edits are detectable.",0,"Done"],\n["Scrutinise","Step 2 · Application scrutiny","Text is extracted from every document and each value keeps its page and position.",0,"Done"],\n["Review","Step 3 · Officer review","Disagreements show both values side by side. Every stage runs against a statutory timeline.",0,"Done"],\n["Decide","Step 4 · Decision","Approval is blocked while a mandatory document is missing, unless an authorised officer records an override.",0,"Done"],\n["Monitor","Step 5 · Compliance monitoring","Rules run on a schedule. Expiring certificates and breaches raise alerts that escalate if no one acts.",0,"Done"],')
rep('["Cross-document matching","Application validation",', '["Cross-document matching","Application scrutiny",')
rep('["Authenticity signals","Document authentication",', '["Authenticity signals","Document scrutiny",')
rep('["Explainable rules","Regulatory compliance",', '["Explainable rules","Compliance monitoring",')
src = src.replace('"Case 4839 · Field"', '"Application 4839 · Field"').replace('"Case 4839 · Compliance rule"', '"Application 4839 · Compliance rule"')
rep('["Case 4839","Sample Institute of Technology (synthetic data)",', '["Application 4839","Sample Institute of Technology (synthetic data)",')
rep('var SN="Reviewer control",SA="Attest recommends. An authorised reviewer approves, rejects, or asks for corrections, and every decision is recorded with a reason.";',
    'var SN="Officer control",SA="Attest recommends. An authorised officer approves, rejects, or requests corrections, and every decision is recorded with a reason.";')

# ------------------------------------------------------------------ JS: data bridge (the only behavioural change)
start = src.index('document.getElementById("run").addEventListener("click",function(){')
end = src.index("function addLog(")
old_run = src[start:end]
bridge = open(__file__.replace("patch_frontend.py", "bridge.js"), encoding="utf-8").read().rstrip("\n") + "\n"
src = src[:start] + bridge + src[end:]
n_edits += 1

old_dec = 'document.querySelectorAll("[data-a]").forEach(b=>b.addEventListener("click",()=>addLog(b.dataset.a+" – Case 4839","Reviewer")));'
rep(old_dec, 'document.querySelectorAll("[data-a]").forEach(b=>b.addEventListener("click",()=>decideCase(b.dataset.a)));')

# log rows get a tone class so alerts, escalations and blocked actions can be coloured
rep('new Date().toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"});d.append(x,y);', 'new Date().toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"});d.className=toneOf(a);d.append(x,y);')

open(sys.argv[2], "w", encoding="utf-8").write(src)
print(f"{n_edits} edits applied -> {sys.argv[2]}")

# colour layer: navy / saffron / ivory (see theme.css)
import subprocess
subprocess.run([sys.executable, __file__.replace("patch_frontend.py", "apply_theme.py"), sys.argv[2]], check=True)
