/* ---- Attest data bridge ---------------------------------------------------------------
   Connects this page to the Node.js gateway on the same origin. Layout, styles and animation
   are untouched. If no backend answers (for example the file is opened directly), the page
   falls back to the embedded sample above and behaves exactly as it did before. */
const OFFLINE={fields:F.map(r=>({label:r[0],cells:r.slice(1,4),status:r[4]})),rules:R.map(r=>({title:r[0],result:r[1]})),score:72,
 evidence:"Evidence: lecture rooms read as 42 on the application form (page 2) and 38 on the infrastructure report (page 1). Fire safety certificate is required by the checklist but not attached.",
 summary:"2 passed, 1 conflict, 1 missing"};
let DATA=OFFLINE;
function setF(d){F.splice(0,F.length,...d.fields.map(f=>[f.label].concat(f.cells,[f.status])))}
const API=(function(){
 const CASE="AICTE-2026-4839";let token=null;
 async function call(path,o){o=o||{};const h={"Content-Type":"application/json"};if(token)h.Authorization="Bearer "+token;
  const r=await fetch(path,{method:o.method||"GET",headers:h,body:o.body?JSON.stringify(o.body):undefined,signal:AbortSignal.timeout?AbortSignal.timeout(20000):undefined});
  const b=await r.json().catch(()=>({}));
  if(!r.ok){const e=new Error((b.error&&b.error.message)||r.statusText);e.status=r.status;throw e}
  return b}
 async function session(){const b=await call("/api/session/demo",{method:"POST"});token=b.token}
 async function authed(p,o){try{return await call(p,o)}catch(e){if(e.status===401){await session();return call(p,o)}throw e}}
 return{session:session,
  preview:()=>authed("/api/cases/"+CASE+"/preview"),
  scrutiny:()=>authed("/api/cases/"+CASE+"/scrutiny",{method:"POST"}),
  decide:d=>authed("/api/cases/"+CASE+"/decision",{method:"POST",body:{decision:d,reason:"Recorded from the officer console"}}),
  audit:()=>authed("/api/cases/"+CASE+"/audit?limit=6"),
  alerts:()=>authed("/api/alerts?status=active&limit=3"),
  ticket:()=>authed("/api/stream-ticket",{method:"POST"})}})();
const READY=API.session().then(()=>API.preview()).then(a=>{DATA=a;setF(a);draw(false);return true}).catch(()=>false);

document.getElementById("run").addEventListener("click",function(){
  const b=this;b.disabled=true;b.textContent="Checking…";
  const ev=document.getElementById("ev"),rl=document.getElementById("rules"),sc=document.getElementById("score"),bar=document.getElementById("bar");
  rl.innerHTML="";sc.textContent="…";bar.style.width="0";ev.textContent="Extracting fields and comparing documents…";
  const t0=Date.now();
  READY.then(ok=>ok?API.scrutiny():null).catch(()=>null).then(res=>{
    const d=res&&res.fields?res:DATA,wait=Math.max(0,900-(Date.now()-t0));
    setTimeout(()=>{setF(d);draw(true);ev.textContent=d.evidence},wait);
    d.rules.forEach((r,i)=>setTimeout(()=>{
      const li=document.createElement("li"),a=document.createElement("span"),t=document.createElement("span");
      a.textContent=r.title;t.className="tag "+(r.result==="Pass"?"ok":r.result==="Review"?"rev":"miss");t.textContent=r.result;li.append(a,t);rl.appendChild(li);
    },wait+400+i*350));
    setTimeout(()=>{sc.textContent=d.score+"%";bar.style.width=d.score+"%";b.disabled=false;b.textContent="Run again";
      addLog("Scrutiny report generated: "+d.summary,"System");},wait+2000);
  });
});
function decideCase(name){
  READY.then(ok=>{
    if(!ok){addLog(name+" – Application 4839","Reviewer");return}
    return API.decide(name).then(r=>addLog(r.message,"Reviewer"),e=>addLog((e.status===409||e.status===403?"Blocked – ":"Error – ")+e.message,"System"));
  });
}
/* Live log: recent audit entries and active alerts on load, then alerts as they are raised. */
function toneOf(t){return/^ALERT/.test(t)?"t-alert":/^ESCALATED|^Alert .* escalated/.test(t)?"t-esc":/^Blocked|^Error/.test(t)?"t-block":""}
function logRow(text,who,iso){const d=document.createElement("div"),x=document.createElement("span"),y=document.createElement("span");d.className=toneOf(text);
 x.textContent=text;y.textContent=who+" · "+new Date(iso||Date.now()).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"});d.append(x,y);document.getElementById("log").appendChild(d)}
function auditText(e){const d=e.details||{};switch(e.action){
 case"CASE_RECEIVED":return"Application 4839 received";
 case"SCRUTINY_COMPLETED":return"Scrutiny completed – compliance score "+d.score+"%";
 case"DECISION_RECORDED":return d.decision+" – Application 4839";
 case"STATE_CHANGED":return"Stage changed – "+(d.reason||d.to);
 case"ALERT_RAISED":return"ALERT · "+String(d.severity).toUpperCase()+" · "+d.message;
 case"ALERT_ESCALATED":return"Alert "+d.alertId+" escalated to level "+d.toLevel;
 case"DOCUMENT_UPLOADED":return"Document received – "+(d.type||"").replace(/_/g," ");
 default:return String(e.action).replace(/_/g," ").toLowerCase()}}
function openStream(){
 API.ticket().then(t=>{
  const es=new EventSource("/api/alerts/stream?ticket="+encodeURIComponent(t.ticket));
  es.addEventListener("alert",m=>{const a=JSON.parse(m.data);addLog("ALERT · "+a.severity.toUpperCase()+" · "+a.message,"Alert engine")});
  es.addEventListener("alert-update",m=>{const a=JSON.parse(m.data);if(a.status==="open"&&a.level>1)addLog("ESCALATED · level "+a.level+" · "+a.id,"Alert engine")});
  es.onerror=()=>{es.close();setTimeout(openStream,8000)};
 }).catch(()=>{});
}
READY.then(async ok=>{
 if(!ok)return;
 try{const h=await API.audit(),log=document.getElementById("log");
  if(h.items.length){log.innerHTML="";h.items.forEach(e=>logRow(auditText(e),e.actor.name,e.ts))}
  const a=await API.alerts();a.items.filter(x=>x.caseId!=="AICTE-2026-4839").forEach(x=>logRow("ALERT · "+x.severity.toUpperCase()+" · "+x.message,"Alert engine",x.occurredAt));
 }catch(e){}
 openStream();
});
