#!/usr/bin/env node
'use strict';
/* Full-stack check against the RUNNING services (gateway, engine, escalation, portal).
   Start them first (node scripts/run-all.js), on a fresh data directory, then:  node scripts/e2e.js */
const G = process.env.GATEWAY_URL || 'http://127.0.0.1:3000';
const P = process.env.PORTAL_URL || 'http://127.0.0.1:8003';
const E = process.env.ESCALATION_URL || 'http://127.0.0.1:8002';
const KEY = process.env.INTERNAL_KEY || 'dev-internal-key';
const PASSWORD = process.env.DEV_PASSWORD || 'Attest@2026';
const CASE = 'AICTE-2026-4839';

let failed = 0;
const check = (name, ok, extra = '') => { console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${extra ? '  ' + extra : ''}`); if (!ok) failed += 1; };
const call = async (base, method, url, { token, body, raw, headers = {} } = {}) => {
  const h = { ...headers };
  if (token) h.Authorization = `Bearer ${token}`;
  if (body !== undefined) h['Content-Type'] = 'application/json';
  const r = await fetch(base + url, { method, headers: h, body: raw ?? (body !== undefined ? JSON.stringify(body) : undefined) });
  const t = await r.text(); let j = null; try { j = JSON.parse(t); } catch { /* */ }
  return { status: r.status, json: j, headers: r.headers };
};

function certificatePdf() {
  const text = 'Fire Safety Certificate \\(NOC\\): Valid till 2027-03-31';
  const stream = `BT /F1 12 Tf 10 50 Td (${text}) Tj ET`;
  return Buffer.from(['%PDF-1.4', '1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj', '2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj',
    '3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 400 100]/Contents 4 0 R/Resources<</Font<</F1 5 0 R>>>>>>endobj',
    `4 0 obj<</Length ${stream.length}>>stream`, stream, 'endstream endobj', '5 0 obj<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>endobj',
    'trailer<</Root 1 0 R>>', '%%EOF', ''].join('\n'));
}

(async () => {
  const login = await call(G, 'POST', '/api/auth/login', { body: { username: 'regional.officer', password: PASSWORD } });
  const token = login.json?.token;
  check('sign in as Regional Officer', !!token);

  const st = (await call(G, 'GET', '/api/system/status', { token })).json;
  check('Node.js gateway up', st.gateway?.up);
  check('Python engine up', st.engine?.up, `(${st.engine?.latencyMs} ms)`);
  check('Java escalation service up', st.escalation?.up, `(${st.escalation?.latencyMs} ms)`);
  check('PHP portal up', st.portal?.up, `(${st.portal?.latencyMs} ms)`);

  const run = await call(G, 'POST', `/api/cases/${CASE}/scrutiny`, { token });
  check('scrutiny reproduces the demo verdict (72%, 1 conflict, 1 missing)', run.json?.score === 72 && /1 conflict, 1 missing/.test(run.json?.summary));

  const gate = await call(G, 'POST', `/api/cases/${CASE}/decision`, { token, body: { decision: 'Approved', reason: 'attempt before the certificate' } });
  check('approval blocked by compliance gate', gate.status === 409 && gate.json?.error?.code === 'COMPLIANCE_GATE');

  const fake = await call(G, 'PUT', `/api/cases/${CASE}/documents/fire_safety_certificate`, { token, raw: Buffer.from('MZ\x90 not really a pdf') });
  check('file that only pretends to be a PDF is refused', fake.status === 415);

  const up = await call(G, 'PUT', `/api/cases/${CASE}/documents/fire_safety_certificate?filename=noc.pdf`, { token, raw: certificatePdf(), headers: { 'Content-Type': 'application/pdf' } });
  check('real PDF uploaded and fingerprinted (SHA-256)', up.status === 201 && up.json?.sha256?.length === 64);

  const rerun = await call(G, 'POST', `/api/cases/${CASE}/scrutiny`, { token });
  check('Python read the PDF text layer; blocking finding cleared', rerun.json?.blocking?.length === 0 && rerun.json?.score === 92, `(score ${rerun.json?.score})`);
  const noc = rerun.json?.documents?.find((d) => d.type === 'fire_safety_certificate');
  check('uploaded document recorded as application/pdf', noc?.mime === 'application/pdf' && noc?.pages === 1);

  const ok = await call(G, 'POST', `/api/cases/${CASE}/decision`, { token, body: { decision: 'Approved', reason: 'All mandatory documents attached and verified' } });
  check('approval recorded', ok.status === 200 && ok.json?.state === 'APPROVED');

  await new Promise((r) => setTimeout(r, 800));
  const outbox = (await call(E, 'GET', '/v1/outbox?limit=100', { headers: { 'X-Internal-Key': KEY } })).json?.items || [];
  check('Java dispatched the institution notice', outbox.some((m) => m.recipients?.[0] === 'INSTITUTION:INST-001'));
  check('Java escalated the overdue SLA alert to level 3', outbox.some((m) => m.level === 3 && /has been at "Under scrutiny"/.test(m.body)), `(${outbox.length} messages in outbox)`);

  const pub = await call(P, 'GET', `/status?ref=${CASE}`);
  check('PHP portal shows the public status', pub.status === 200 && pub.json?.stage === 'APPROVED');
  check('PHP portal exposes only whitelisted fields', pub.json && Object.keys(pub.json).every((k) => ['reference', 'institution', 'stage', 'stageLabel', 'outcome', 'lastUpdated', 'expectedBy'].includes(k)));
  check('PHP portal rejects malformed references', (await call(P, 'GET', '/status?ref=../../etc/passwd')).status === 400);
  check('internal API is closed to the public without the key', (await call(G, 'GET', `/internal/public/applications/${CASE}`)).status === 401);

  const mon = (await call(G, 'GET', '/api/monitoring/institutions', { token })).json;
  const worst = mon?.results?.map((r) => r.complianceIndex).sort((a, b) => a - b)[0];
  check('continuous monitoring ran for every institution', mon?.results?.length === 4, `(lowest compliance index ${worst}%)`);
  const active = (await call(G, 'GET', '/api/alerts?status=active', { token })).json?.items || [];
  check('alerts raised for SLA breaches and compliance lapses', active.some((a) => a.type === 'SLA_BREACH') && active.some((a) => a.type === 'COMPLIANCE_BREACH'), `(${active.length} active)`);

  const verify = (await call(G, 'GET', '/api/audit/verify', { token })).json;
  check('audit hash chain intact', verify?.valid === true, `(${verify?.entries} entries)`);

  console.log(failed ? `\n${failed} check(s) FAILED` : '\nAll end-to-end checks passed');
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.error('e2e crashed:', e); process.exit(1); });
