"""Proves the front end was not redesigned: compares the original page with the shipped one.
Usage: python3 scripts/verify_frontend.py"""
import difflib, hashlib, re
from pathlib import Path

root = Path(__file__).resolve().parents[1]
a = (root / "docs/original-attest.html").read_text(encoding="utf-8")
b = (root / "gateway/public/index.html").read_text(encoding="utf-8")

css = lambda s: "".join(re.findall(r"<style>(.*?)</style>", s, re.S))
tags = lambda s: re.findall(r"<(/?[a-zA-Z][a-zA-Z0-9]*)[ >/]", re.sub(r"<script.*?</script>|<style.*?</style>", "", s, flags=re.S))
attrs = lambda s: re.findall(r'(?:class|id)="([^"]*)"', s)

ca, cb = css(a), css(b)
layout_a = ca[:ca.index("html:root:root{")].rstrip("\n")        # original layout CSS, before the old colour layer
layout_b = cb[:cb.index("/* ATTEST-THEME")].rstrip("\n")        # same position in the shipped page
print("layout CSS byte-identical: ", layout_a == layout_b, "sha256", hashlib.sha256(layout_a.encode()).hexdigest()[:16])
print("colour layer replaced:      old", len(ca) - len(layout_a), "chars -> new", len(cb) - len(layout_b), "chars (scripts/theme.css)")
print("class/id attributes same:  ", attrs(a) == attrs(b))
for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, tags(a), tags(b), autojunk=False).get_opcodes():
    if op != "equal":
        print("markup difference:         ", op, tags(a)[i1:i2], "->", tags(b)[j1:j2], "(hero sentence is one word shorter)")
