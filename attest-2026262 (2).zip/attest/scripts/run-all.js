#!/usr/bin/env node
'use strict';
/* Starts the whole Attest stack with one command:  node scripts/run-all.js
   Python engine :8001   Java escalation :8002   PHP portal :8003   Node gateway + website :3000
   A service whose runtime is missing is skipped with a warning; the gateway keeps working
   (it falls back to a built-in escalation matrix, and reports the engine as unavailable). */
const { spawn, spawnSync } = require('node:child_process');
const crypto = require('node:crypto');
const path = require('node:path');

const ROOT = path.resolve(__dirname, '..');
const KEY = process.env.INTERNAL_KEY || crypto.randomBytes(16).toString('hex');
const DATA = path.resolve(process.env.DATA_DIR || path.join(ROOT, 'gateway', 'data'));
const PORT = process.env.PORT || '3000';

const works = (cmd, args = ['--version']) => { try { return spawnSync(cmd, args, { stdio: 'ignore' }).status === 0; } catch { return false; } };
const firstWorking = (list) => list.find((c) => works(c));

const python = firstWorking(['python3', 'python', 'py']);
const env = { ...process.env, INTERNAL_KEY: KEY, DATA_DIR: DATA };
const services = [
  { name: 'engine', color: 36, cmd: python, cwd: 'engine', needs: 'Python 3.10+',
    ready: python && works(python, ['-c', 'import fastapi, uvicorn']),
    hint: 'pip install -r engine/requirements.txt',
    args: ['-m', 'uvicorn', 'app:app', '--host', '127.0.0.1', '--port', '8001', '--log-level', 'warning'], env: {} },
  { name: 'escalation', color: 33, cmd: 'java', cwd: 'escalation', needs: 'Java 17+ (JDK)', ready: works('java', ['-version']),
    args: ['EscalationService.java'], env: { PORT: '8002', OUTBOX_FILE: path.join(DATA, 'outbox.jsonl') } },
  { name: 'portal', color: 35, cmd: 'php', cwd: 'portal', needs: 'PHP 8.1+', ready: works('php'),
    args: ['-S', '127.0.0.1:8003', 'index.php'], env: { GATEWAY_URL: `http://127.0.0.1:${PORT}` } },
  { name: 'gateway', color: 32, cmd: process.execPath, cwd: 'gateway', needs: 'Node 20+', ready: true,
    args: ['src/server.js'], env: {} },
];

const children = [];
const prefix = (name, color) => (chunk) => String(chunk).split(/\r?\n/).filter(Boolean)
  .forEach((l) => console.log(`\x1b[${color}m[${name}]\x1b[0m ${l}`));

for (const s of services) {
  if (!s.ready) {
    console.warn(`\x1b[31m[${s.name}] skipped: ${s.needs} not found${s.hint ? ` or dependencies missing (${s.hint})` : ''}\x1b[0m`);
    continue;
  }
  const child = spawn(s.cmd, s.args, { cwd: path.join(ROOT, s.cwd), env: { ...env, ...s.env }, stdio: ['ignore', 'pipe', 'pipe'] });
  child.stdout.on('data', prefix(s.name, s.color));
  child.stderr.on('data', prefix(s.name, s.color));
  child.on('exit', (code) => console.log(`\x1b[${s.color}m[${s.name}]\x1b[0m exited (${code})`));
  children.push(child);
}

const stop = () => { children.forEach((c) => c.kill()); setTimeout(() => process.exit(0), 500); };
process.on('SIGINT', stop);
process.on('SIGTERM', stop);
console.log(`\nOpen  http://127.0.0.1:${PORT}   (Ctrl+C stops everything)\n`);
