"""Replaces the colour layer at the end of the page's stylesheet with scripts/theme.css.
Everything before the layer (the layout CSS) is left byte-for-byte as it was.
Usage: python3 apply_theme.py page.html   (safe to run repeatedly)"""
import re, sys
from pathlib import Path

page = Path(sys.argv[1])
html = page.read_text(encoding="utf-8")
theme = (Path(__file__).with_name("theme.css")).read_text(encoding="utf-8").strip() + "\n"

m = re.search(r"<style>(.*?)</style>", html, re.S)
css = m.group(1)
# the old colour layer starts at 'html:root:root{', a re-run starts at the theme marker
cut = css.find("/* ATTEST-THEME")
if cut < 0:
    cut = css.find("html:root:root{")
assert cut > 0, "could not find where the colour layer starts"
page.write_text(html[:m.start(1)] + css[:cut].rstrip("\n") + "\n" + theme + html[m.end(1):], encoding="utf-8")
print(f"theme applied: layout CSS kept ({cut} chars), colour layer replaced ({len(theme)} chars)")
