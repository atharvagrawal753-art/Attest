<?php
declare(strict_types=1);

/**
 * Attest public transparency portal (PHP).
 *
 * The only component meant to face the open internet. It is read-only, holds no database
 * credentials and no user accounts: it asks the gateway's internal API for one application
 * at a time, keeps only a whitelisted set of fields, rate-limits by IP and caches briefly.
 * Even if this layer were compromised, scores, officer names and documents are not reachable.
 *
 * Run:  php -S 127.0.0.1:8003 index.php
 *   GET /status?ref=AICTE-2026-4839
 *   GET /health
 */

const PUBLIC_FIELDS = ['reference', 'institution', 'stage', 'stageLabel', 'outcome', 'lastUpdated', 'expectedBy'];

$config = [
    'gateway'   => rtrim(getenv('GATEWAY_URL') ?: 'http://127.0.0.1:3000', '/'),
    'key'       => getenv('INTERNAL_KEY') ?: '',
    'limit'     => (int)(getenv('PORTAL_RATE_LIMIT') ?: 30),   // requests per IP per minute
    'cacheTtl'  => (int)(getenv('PORTAL_CACHE_TTL') ?: 15),    // seconds
    'stateDir'  => getenv('PORTAL_STATE_DIR') ?: sys_get_temp_dir() . '/attest-portal',
];

function respond(int $status, array $body, array $headers = []): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: no-referrer');
    header("Content-Security-Policy: default-src 'none'; frame-ancestors 'none'");
    header('Access-Control-Allow-Origin: *');          // public, read-only data
    foreach ($headers as $name => $value) {
        header("$name: $value");
    }
    echo json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function ensureDir(string $dir): void
{
    if (!is_dir($dir) && !@mkdir($dir, 0700, true) && !is_dir($dir)) {
        respond(500, ['error' => ['code' => 'STATE_DIR', 'message' => 'Portal storage is unavailable.']]);
    }
}

/** Fixed-window limiter: one small counter file per IP per minute, guarded by flock. */
function rateLimit(string $dir, string $ip, int $limit): array
{
    $window = intdiv(time(), 60);
    $file = $dir . '/rl-' . sha1($ip) . '-' . $window;
    $fh = fopen($file, 'c+');
    flock($fh, LOCK_EX);
    $count = (int)stream_get_contents($fh) + 1;
    ftruncate($fh, 0);
    rewind($fh);
    fwrite($fh, (string)$count);
    flock($fh, LOCK_UN);
    fclose($fh);

    if (random_int(1, 100) === 1) {                     // opportunistic cleanup of old windows
        foreach (glob($dir . '/rl-*') ?: [] as $old) {
            if (filemtime($old) < time() - 180) {
                @unlink($old);
            }
        }
    }
    return [$count <= $limit, max(0, $limit - $count)];
}

function fetchFromGateway(array $cfg, string $ref): array
{
    $url = $cfg['gateway'] . '/internal/public/applications/' . rawurlencode($ref);
    $context = stream_context_create(['http' => [
        'method' => 'GET',
        'header' => "Accept: application/json\r\nX-Internal-Key: {$cfg['key']}\r\n",
        'timeout' => 4,
        'ignore_errors' => true,
    ]]);
    $raw = @file_get_contents($url, false, $context);
    if ($raw === false || empty($http_response_header[0])) {
        return [502, null];
    }
    preg_match('#HTTP/\S+\s+(\d{3})#', $http_response_header[0], $m);
    $status = (int)($m[1] ?? 502);
    $data = json_decode($raw, true);
    return [$status, is_array($data) ? $data : null];
}

// ------------------------------------------------------------------------------ routing
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'OPTIONS') {
    respond(204, [], ['Access-Control-Allow-Methods' => 'GET, OPTIONS']);
}
if ($method !== 'GET') {
    respond(405, ['error' => ['code' => 'METHOD', 'message' => 'Only GET is supported.']], ['Allow' => 'GET, OPTIONS']);
}

if ($path === '/health') {
    respond(200, ['status' => 'ok', 'service' => 'portal', 'version' => '1.0.0']);
}

if ($path === '/') {
    respond(200, ['service' => 'Attest public status portal', 'endpoints' => ['/status?ref=AICTE-2026-4839']]);
}

if ($path !== '/status') {
    respond(404, ['error' => ['code' => 'NOT_FOUND', 'message' => 'Unknown endpoint.']]);
}

ensureDir($config['stateDir']);
$ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
[$allowed, $remaining] = rateLimit($config['stateDir'], $ip, $config['limit']);
if (!$allowed) {
    respond(429, ['error' => ['code' => 'RATE_LIMITED', 'message' => 'Too many requests. Please try again in a minute.']], ['Retry-After' => '60']);
}

$ref = strtoupper(trim((string)($_GET['ref'] ?? '')));
if (!preg_match('/^AICTE-\d{4}-\d{3,6}$/', $ref)) {
    respond(400, ['error' => ['code' => 'BAD_REFERENCE', 'message' => 'Reference must look like AICTE-2026-4839.']],
        ['X-RateLimit-Remaining' => (string)$remaining]);
}

$cacheFile = $config['stateDir'] . '/cache-' . sha1($ref) . '.json';
if (is_file($cacheFile) && filemtime($cacheFile) > time() - $config['cacheTtl']) {
    $cached = json_decode((string)file_get_contents($cacheFile), true);
    if (is_array($cached)) {
        respond(200, $cached, ['X-Cache' => 'HIT', 'X-RateLimit-Remaining' => (string)$remaining]);
    }
}

[$status, $data] = fetchFromGateway($config, $ref);
if ($status === 404) {
    respond(404, ['error' => ['code' => 'NOT_FOUND', 'message' => 'No application found for this reference.']],
        ['X-RateLimit-Remaining' => (string)$remaining]);
}
if ($status !== 200 || $data === null) {
    respond(502, ['error' => ['code' => 'UPSTREAM', 'message' => 'Status is temporarily unavailable.']]);
}

$public = array_intersect_key($data, array_flip(PUBLIC_FIELDS));   // drop everything not whitelisted
file_put_contents($cacheFile, json_encode($public), LOCK_EX);
respond(200, $public, ['X-Cache' => 'MISS', 'X-RateLimit-Remaining' => (string)$remaining,
                       'Cache-Control' => 'public, max-age=' . $config['cacheTtl']]);
