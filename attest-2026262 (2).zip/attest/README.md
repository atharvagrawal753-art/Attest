# Attest — Integrated AICTE Approval Workflow Automation, Compliance Monitoring and Alert Management

Smart India Hackathon 2026 · Problem Statement **2026262** · Prototype (not an official AICTE portal; all data is synthetic)

The website you built is unchanged visually. Behind it is now a real backend: an approval workflow engine,
a rule-driven compliance engine, an alert/escalation system and a tamper-evident audit trail.

## Architecture

```
Browser ──► Node.js gateway :3000 ─────► Python engine :8001    reads PDFs, cross-checks documents,
 (your       website + REST API   │                              runs the rule set, scores compliance
 Attest      workflow, RBAC/JWT,  ├────► Java service :8002       escalation matrix (L1→L2→L3) and
 page)       alerts (live SSE),   │                              notification dispatch (outbox)
             audit hash chain     │
Public ───► PHP portal :8003 ─────┘      read-only status lookup; asks the gateway's internal API,
 internet    (rate-limited, cached)      returns 7 whitelisted fields only
```

| Part | Language | Why this language |
|---|---|---|
| Gateway: workflow state machine, auth, RBAC, alerts, SLA jobs, audit | Node.js | I/O-heavy, real-time (SSE) |
| Document intelligence + compliance rules (`engine/rules.json`) | Python | PDF/OCR ecosystem |
| Escalation matrix + notification dispatch | Java | typed, enterprise-style integration |
| Public status portal | PHP | commonly hosted on public gov. servers; kept read-only and isolated |

## Run it

Needs Node 20+, Python 3.10+, Java 17+ (JDK), PHP 8.1+ (any missing one is skipped with a warning).

```bash
npm run install:all      # gateway dependencies + engine dependencies
npm start                # starts all four services, open http://127.0.0.1:3000
npm test                 # 23 gateway tests;  cd engine && python -m unittest discover -s tests
npm run e2e              # full-stack check (needs the same INTERNAL_KEY as the running stack)
```

Sample accounts (development only, password `Attest@2026`): `admin`, `scrutiny.officer`, `expert.member`,
`regional.officer`, `sample.institution`. The website itself signs in as a demo officer automatically (`DEMO_MODE`).

## Demo script (2 minutes)

1. Open the site → click **Run a sample scrutiny**. The Python engine reads three documents, finds the room-count conflict (42 vs 38, with page numbers) and the missing fire certificate → 72 %.
2. Click **Approve** → blocked by the *compliance gate* with the reason. Click **Request correction** → recorded; the institution is notified (see `gateway/data/outbox.jsonl`).
3. The log at the bottom shows live alerts: an overdue application already escalated to level 3, an expiring fire certificate, a faculty-ratio breach.
4. Upload the missing certificate (`PUT /api/cases/AICTE-2026-4839/documents/fire_safety_certificate`, see `scripts/e2e.js`), re-run scrutiny → blocking finding gone, 92 %, approval now allowed.
5. `GET /api/audit/verify` → chain valid. Edit one character in `gateway/data/audit.jsonl` → it names the exact entry that was altered.
6. `http://127.0.0.1:8003/status?ref=AICTE-2026-4839` → the public view, nothing sensitive.

## What the backend does

- **Workflow** (`gateway/src/workflow.js`): Received → Scrutiny → Expert review → Approved / Rejected, with *Correction requested* loop; per-stage deadlines (SLA days are illustrative config).
- **Compliance gate**: approval is refused while a mandatory document is missing; only a Regional Officer can override, with a written reason (≥ 15 chars), which is audited.
- **Compliance monitoring**: every institution is evaluated on a schedule (faculty-student ratio, fire-certificate and accreditation expiry, land area, mandatory disclosure). Thresholds live in `engine/rules.json` — change a number, the verdict changes, no code edit.
- **Alerts**: SLA warning/breach/critical, compliance breach/warning, missing document, data conflict, authenticity signals. De-duplicated, auto-resolved when fixed, acknowledged by officers, pushed live to the page, escalated L1→L2→L3 by the Java matrix (critical 0/30/120 min, high 0/4 h/24 h, medium 0/24 h/72 h, low 0/72 h).
- **Authenticity signals** (PDF): incremental saves, editing-tool metadata, modified-after-creation, stripped metadata, same file submitted by two institutions. Always worded as *signals to examine*, never as proof of fraud.
- **Audit trail**: append-only file, each entry carries the hash of the previous one.

## Security measures actually implemented

scrypt password hashing · JWT (HS256, role re-read from the database on every request) · login lockout (5 tries / 15 min) · role-based permissions checked server-side before case state is revealed · institutions can only see their own cases (others return 404) · rate limits · helmet security headers + CSP · uploads judged by file *content* (magic bytes), size-limited, stored under their SHA-256 · constant-time key checks between services · production mode refuses to start without `JWT_SECRET`, `INTERNAL_KEY`, `ADMIN_PASSWORD` · no stack traces in responses.

## Honest limits (read before presenting)

- Data is synthetic. Rule thresholds and SLA days are **illustrative**; align them with the current AICTE Approval Process Handbook before claiming compliance.
- Scanned PDFs / images need an OCR engine (`pytesseract`); without one the engine reports "OCR required" instead of guessing. Digital PDFs work out of the box.
- E-mail/SMS are **simulated** (written to an outbox file). Replace `deliver()` in `escalation/EscalationService.java` with a real gateway.
- Storage is one JSON file (atomic writes). Fine for a prototype; swap `gateway/src/store.js` for PostgreSQL before real use.
- `DEMO_MODE` opens an officer session without login so the page works as a demo. **Turn it off in production** (it is off by default when `NODE_ENV=production`).
- Rendered and clicked through in WebKit only. `CSP_MODE=strict` is implemented and its hashes are verified, but check it in Chrome/Firefox before relying on it.
- Docker files are not included.

## Front end

The page is rebuilt from `docs/original-attest.html` by one command: `python3 scripts/patch_frontend.py docs/original-attest.html gateway/public/index.html`
(exact-match edits for the wording and the data bridge, then `scripts/apply_theme.py` applies the colour theme).

- **Theme** (`scripts/theme.css`): navy `#0A1A33`, saffron `#FF9933`, ivory `#F6F4EE`, with flag-green for "pass" and red for "missing". The intro and sphere are dark navy; the working site is light ivory with a saffron-white-green stripe; the officer console is navy. Status colours are consistent everywhere (green pass, amber review, red missing).
- **What was kept**: all layout CSS (the stylesheet above the theme marker is byte-identical to your original), every HTML class/id, and every animation. `python3 scripts/verify_frontend.py` shows this.
- **Rendering check**: the page was rendered in WebKit (Safari's engine) at desktop and phone sizes. It has not been checked in Chrome or Firefox.
- Opened without a backend, the page falls back to its embedded sample and works as before.
