import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Executors;

/**
 * Attest escalation and notification service.
 *
 * Decides which level of authority an unattended alert must reach, and dispatches the
 * notification. Channels (IN_APP, EMAIL, SMS) are written to an outbox file here; swapping in
 * a real mail or SMS gateway only means changing {@link #deliver}.
 *
 * Run with:  java EscalationService.java        (JDK 17+, no build step, no dependencies)
 * Self-test: java EscalationService.java --selftest
 */
public class EscalationService {

    /** Minutes an alert may stay unattended before it reaches level 1, 2 and 3. */
    static final Map<String, long[]> MATRIX = new LinkedHashMap<>();
    static {
        MATRIX.put("critical", new long[]{0, 30, 120});
        MATRIX.put("high",     new long[]{0, 240, 1440});
        MATRIX.put("medium",   new long[]{0, 1440, 4320});
        MATRIX.put("low",      new long[]{0, 4320, Long.MAX_VALUE});
    }
    static final String[][] NOTIFY = {
        {"SCRUTINY_OFFICER"},
        {"SCRUTINY_OFFICER", "REGIONAL_OFFICER"},
        {"SCRUTINY_OFFICER", "REGIONAL_OFFICER", "MEMBER_SECRETARY"}
    };
    static final String[][] CHANNELS = {
        {"IN_APP"},
        {"IN_APP", "EMAIL"},
        {"IN_APP", "EMAIL", "SMS"}
    };

    static final String INTERNAL_KEY = env("INTERNAL_KEY", "");
    static final Path OUTBOX = Path.of(env("OUTBOX_FILE", "outbox.jsonl"));
    static final int MAX_BODY = 64 * 1024;
    static final Object OUTBOX_LOCK = new Object();

    // ------------------------------------------------------------------ decision logic
    record Decision(int level, long nextInMinutes) {}

    static Decision decide(String severity, long ageMinutes) {
        long[] t = MATRIX.get(severity);
        int level = 1;
        for (int i = 1; i < t.length; i++) {
            if (ageMinutes >= t[i]) level = i + 1;
        }
        long next = (level < t.length && t[level] != Long.MAX_VALUE) ? t[level] - ageMinutes : -1;
        return new Decision(level, next);
    }

    // ------------------------------------------------------------------------- http
    public static void main(String[] args) throws Exception {
        if (args.length > 0 && args[0].equals("--selftest")) {
            System.exit(selfTest() ? 0 : 1);
        }
        int port = Integer.parseInt(env("PORT", "8002"));
        String host = env("HOST", "127.0.0.1");
        HttpServer server = HttpServer.create(new InetSocketAddress(host, port), 0);
        server.createContext("/health", ex -> guard(ex, false, EscalationService::health));
        server.createContext("/v1/escalation", ex -> guard(ex, true, EscalationService::escalation));
        server.createContext("/v1/dispatch", ex -> guard(ex, true, EscalationService::dispatch));
        server.createContext("/v1/outbox", ex -> guard(ex, true, EscalationService::outbox));
        server.setExecutor(Executors.newFixedThreadPool(8));
        server.start();
        System.out.println("[escalation] listening on http://" + host + ":" + port + "  outbox=" + OUTBOX.toAbsolutePath());
    }

    interface Handler { void handle(HttpExchange ex) throws Exception; }

    /** Authenticates the caller, turns exceptions into JSON errors, never leaks stack traces. */
    static void guard(HttpExchange ex, boolean needsKey, Handler h) throws IOException {
        try {
            if (needsKey && !INTERNAL_KEY.isEmpty()) {
                String given = ex.getRequestHeaders().getFirst("X-Internal-Key");
                boolean ok = given != null && MessageDigest.isEqual(
                        given.getBytes(StandardCharsets.UTF_8), INTERNAL_KEY.getBytes(StandardCharsets.UTF_8));
                if (!ok) { send(ex, 401, "{\"error\":\"invalid internal key\"}"); return; }
            }
            h.handle(ex);
        } catch (IllegalArgumentException e) {
            send(ex, 400, "{\"error\":" + q(e.getMessage()) + "}");
        } catch (Exception e) {
            System.err.println("[escalation] error: " + e);
            send(ex, 500, "{\"error\":\"internal error\"}");
        }
    }

    static void health(HttpExchange ex) throws IOException {
        send(ex, 200, "{\"status\":\"ok\",\"service\":\"escalation\",\"version\":\"1.0.0\"}");
    }

    static void escalation(HttpExchange ex) throws IOException {
        if (!ex.getRequestMethod().equals("GET")) { send(ex, 405, "{\"error\":\"method not allowed\"}"); return; }
        Map<String, String> p = parseForm(ex.getRequestURI().getRawQuery());
        String severity = String.valueOf(p.get("severity")).toLowerCase();
        if (!MATRIX.containsKey(severity)) throw new IllegalArgumentException("severity must be critical, high, medium or low");
        long age;
        try { age = Long.parseLong(String.valueOf(p.get("ageMinutes"))); }
        catch (NumberFormatException e) { throw new IllegalArgumentException("ageMinutes must be a whole number"); }
        if (age < 0) throw new IllegalArgumentException("ageMinutes must not be negative");

        Decision d = decide(severity, age);
        String json = "{\"severity\":" + q(severity) + ",\"ageMinutes\":" + age + ",\"level\":" + d.level()
                + ",\"notify\":" + arr(NOTIFY[d.level() - 1]) + ",\"channels\":" + arr(CHANNELS[d.level() - 1])
                + ",\"nextLevelInMinutes\":" + (d.nextInMinutes() < 0 ? "null" : String.valueOf(d.nextInMinutes())) + "}";
        send(ex, 200, json);
    }

    static void dispatch(HttpExchange ex) throws IOException {
        if (!ex.getRequestMethod().equals("POST")) { send(ex, 405, "{\"error\":\"method not allowed\"}"); return; }
        Map<String, String> f = parseForm(readBody(ex.getRequestBody()));
        String alertId = require(f, "alertId", 64);
        String severity = require(f, "severity", 16).toLowerCase();
        if (!MATRIX.containsKey(severity)) throw new IllegalArgumentException("unknown severity");
        int level;
        try { level = Integer.parseInt(require(f, "level", 2)); }
        catch (NumberFormatException e) { throw new IllegalArgumentException("level must be 1, 2 or 3"); }
        if (level < 1 || level > 3) throw new IllegalArgumentException("level must be 1, 2 or 3");
        String subject = require(f, "subject", 200);
        String body = f.getOrDefault("body", "");
        if (body.length() > 2000) throw new IllegalArgumentException("body too long");

        // Optional overrides, e.g. a notice to an institution instead of the officer chain.
        String[] recipients = list(f.get("recipients"), NOTIFY[level - 1]);
        String[] channels = list(f.get("channels"), CHANNELS[level - 1]);

        String id = UUID.randomUUID().toString();
        String line = "{\"id\":" + q(id) + ",\"ts\":" + q(Instant.now().toString()) + ",\"alertId\":" + q(alertId)
                + ",\"level\":" + level + ",\"severity\":" + q(severity)
                + ",\"recipients\":" + arr(recipients) + ",\"channels\":" + arr(channels)
                + ",\"subject\":" + q(subject) + ",\"body\":" + q(body) + "}";
        deliver(line);
        send(ex, 200, "{\"dispatched\":true,\"id\":" + q(id) + ",\"channels\":" + arr(channels) + "}");
    }

    static void outbox(HttpExchange ex) throws IOException {
        Map<String, String> p = parseForm(ex.getRequestURI().getRawQuery());
        int limit = 20;
        try { if (p.containsKey("limit")) limit = Math.max(1, Math.min(100, Integer.parseInt(p.get("limit")))); }
        catch (NumberFormatException ignored) { }
        List<String> lines = new ArrayList<>();
        synchronized (OUTBOX_LOCK) {
            if (Files.exists(OUTBOX)) lines = Files.readAllLines(OUTBOX, StandardCharsets.UTF_8);
        }
        int from = Math.max(0, lines.size() - limit);
        send(ex, 200, "{\"items\":[" + String.join(",", lines.subList(from, lines.size())) + "]}");
    }

    /** The single place a real e-mail / SMS gateway would be plugged in. */
    static void deliver(String jsonLine) throws IOException {
        synchronized (OUTBOX_LOCK) {
            Files.writeString(OUTBOX, jsonLine + "\n", StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        }
    }

    // --------------------------------------------------------------------- helpers
    static String env(String k, String d) { String v = System.getenv(k); return v == null || v.isEmpty() ? d : v; }

    /** Comma-separated list from a form field, restricted to safe characters; falls back to a default. */
    static String[] list(String raw, String[] fallback) {
        if (raw == null || raw.isBlank()) return fallback;
        if (raw.length() > 200) throw new IllegalArgumentException("list too long");
        String[] items = raw.split(",");
        for (int i = 0; i < items.length; i++) {
            items[i] = items[i].trim();
            if (!items[i].matches("[A-Za-z0-9_.@:-]{1,80}")) throw new IllegalArgumentException("invalid list item");
        }
        return items;
    }

    static String require(Map<String, String> m, String key, int max) {
        String v = m.get(key);
        if (v == null || v.isBlank()) throw new IllegalArgumentException(key + " is required");
        if (v.length() > max) throw new IllegalArgumentException(key + " is too long");
        return v;
    }

    static String readBody(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) > 0) {
            out.write(buf, 0, n);
            if (out.size() > MAX_BODY) throw new IllegalArgumentException("request body too large");
        }
        return out.toString(StandardCharsets.UTF_8);
    }

    static Map<String, String> parseForm(String raw) {
        Map<String, String> m = new HashMap<>();
        if (raw == null || raw.isEmpty()) return m;
        for (String pair : raw.split("&")) {
            int i = pair.indexOf('=');
            String k = i < 0 ? pair : pair.substring(0, i);
            String v = i < 0 ? "" : pair.substring(i + 1);
            m.put(URLDecoder.decode(k, StandardCharsets.UTF_8), URLDecoder.decode(v, StandardCharsets.UTF_8));
        }
        return m;
    }

    static String q(String s) {
        StringBuilder b = new StringBuilder("\"");
        for (char c : s.toCharArray()) {
            switch (c) {
                case '"' -> b.append("\\\"");
                case '\\' -> b.append("\\\\");
                case '\n' -> b.append("\\n");
                case '\r' -> b.append("\\r");
                case '\t' -> b.append("\\t");
                default -> { if (c < 0x20) b.append(String.format("\\u%04x", (int) c)); else b.append(c); }
            }
        }
        return b.append('"').toString();
    }

    static String arr(String[] items) {
        List<String> out = new ArrayList<>();
        for (String s : items) out.add(q(s));
        return "[" + String.join(",", out) + "]";
    }

    static void send(HttpExchange ex, int status, String json) throws IOException {
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        ex.getResponseHeaders().set("Cache-Control", "no-store");
        ex.getResponseHeaders().set("X-Content-Type-Options", "nosniff");
        ex.sendResponseHeaders(status, bytes.length);
        try (var os = ex.getResponseBody()) { os.write(bytes); }
    }

    // --------------------------------------------------------------------- self-test
    static boolean selfTest() {
        Object[][] cases = {
            {"critical", 0L, 1}, {"critical", 30L, 2}, {"critical", 120L, 3},
            {"high", 239L, 1}, {"high", 240L, 2}, {"high", 2880L, 3},
            {"medium", 1439L, 1}, {"medium", 1440L, 2}, {"medium", 4320L, 3},
            {"low", 4319L, 1}, {"low", 4320L, 2}, {"low", 999999L, 2},
        };
        boolean ok = true;
        for (Object[] c : cases) {
            int got = decide((String) c[0], (Long) c[1]).level();
            boolean pass = got == (Integer) c[2];
            ok &= pass;
            System.out.println((pass ? "PASS " : "FAIL ") + c[0] + " @" + c[1] + "min -> L" + got + " (expected L" + c[2] + ")");
        }
        boolean json = q("a\"b\\c\nd").equals("\"a\\\"b\\\\c\\nd\"");
        System.out.println((json ? "PASS " : "FAIL ") + "json escaping");
        return ok && json;
    }
}
