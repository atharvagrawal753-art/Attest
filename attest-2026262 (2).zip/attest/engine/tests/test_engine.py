import base64
import json
import sys
import unittest
from datetime import date, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "engine"))

import pymupdf  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

import authenticity  # noqa: E402
import rules as R  # noqa: E402
from app import app  # noqa: E402

SAMPLE = json.loads((ROOT / "shared" / "sample-case-4839.json").read_text(encoding="utf-8"))


def make_pdf(lines, producer=None):
    doc = pymupdf.open()
    page = doc.new_page()
    page.insert_text((72, 72), "\n".join(lines))
    if producer:
        doc.set_metadata({"producer": producer, "creator": producer})
    data = doc.tobytes()
    doc.close()
    return data


class Scrutiny(unittest.TestCase):
    def test_sample_case_matches_the_published_demo(self):
        r = R.analyse_documents(SAMPLE["documents"])
        rows = {f["key"]: (f["cells"], f["status"]) for f in r["fields"]}
        self.assertEqual(rows["lecture_rooms"], (["42", "–", "38"], "bad"))
        self.assertEqual(rows["fire_safety"][1], "miss")
        self.assertEqual(rows["faculty_qualification"], (["–", "Ph.D., CS", "–"], "ok"))
        self.assertEqual([x["result"] for x in r["rules"]], ["Pass", "Pass", "Review", "Missing"])
        self.assertEqual(r["score"], 72)
        self.assertEqual(r["summary"], "2 passed, 1 conflict, 1 missing")
        self.assertIn("42 on the application form (page 2) and 38 on the infrastructure report (page 1)", r["evidence"])
        self.assertEqual(r["blocking"][0]["ruleId"], "mandatory_docs")

    def test_uploading_the_certificate_clears_the_blocking_finding(self):
        docs = SAMPLE["documents"] + [{"type": "fire_safety_certificate",
                                       "pages": ["Fire Safety Certificate (NOC): Valid till 2027-03-31"]}]
        r = R.analyse_documents(docs)
        self.assertEqual(r["blocking"], [])
        self.assertEqual(r["score"], 92)

    def test_minimum_value_fails_below_threshold(self):
        docs = json.loads(json.dumps(SAMPLE["documents"]))
        for d in docs:
            d["pages"] = [p.replace("64", "30") for p in d["pages"]]
        r = R.analyse_documents(docs)
        faculty = next(x for x in r["rules"] if x["id"] == "faculty_min")
        self.assertEqual(faculty["result"], "Fail")

    def test_changing_the_config_changes_the_verdict(self):
        rules = R.load_rules()
        next(x for x in rules["scrutiny"]["rules"] if x["id"] == "faculty_min")["min"] = 100
        r = R.analyse_documents(SAMPLE["documents"], rules)
        self.assertEqual(next(x for x in r["rules"] if x["id"] == "faculty_min")["result"], "Fail")


class Monitoring(unittest.TestCase):
    def setUp(self):
        self.today = date(2026, 10, 31)

    def profile(self, **over):
        base = {"faculty_count": 64, "students_enrolled": 1200, "land_area_acres": 5.0,
                "mandatory_disclosure_filed": True,
                "fire_noc_valid_till": (self.today + timedelta(days=365)).isoformat(),
                "accreditation_valid_till": (self.today + timedelta(days=365)).isoformat()}
        base.update(over)
        return {"id": "I1", "name": "Sample College", "profile": base}

    def test_fully_compliant(self):
        r = R.monitor_institution(self.profile(), self.today)
        self.assertEqual(r["complianceIndex"], 100)
        self.assertEqual(r["findings"], [])

    def test_expiring_and_expired_certificates(self):
        soon = (self.today + timedelta(days=12)).isoformat()
        gone = (self.today - timedelta(days=5)).isoformat()
        warn = R.monitor_institution(self.profile(fire_noc_valid_till=soon), self.today)["findings"][0]
        self.assertEqual((warn["ruleId"], warn["status"], warn["severity"]), ("FIRE_NOC", "warning", "high"))
        breach = R.monitor_institution(self.profile(fire_noc_valid_till=gone), self.today)["findings"][0]
        self.assertEqual((breach["status"], breach["severity"]), ("breach", "critical"))

    def test_ratio_breach_and_missing_data(self):
        r = R.monitor_institution(self.profile(students_enrolled=1500, land_area_acres=None), self.today)
        status = {c["ruleId"]: c["status"] for c in r["checks"]}
        self.assertEqual(status["FSR"], "breach")
        self.assertEqual(status["LAND_AREA"], "unknown")


class Authenticity(unittest.TestCase):
    def test_clean_pdf_has_no_editing_signal(self):
        codes = {s["code"] for s in authenticity.inspect_pdf(make_pdf(["hello"]), "x")}
        self.assertNotIn("EDITING_TOOL", codes)

    def test_editing_tool_is_flagged_as_a_signal_not_proof(self):
        sig = authenticity.inspect_pdf(make_pdf(["hello"], producer="Adobe Photoshop 25"), "x")
        tool = next(s for s in sig if s["code"] == "EDITING_TOOL")
        self.assertIn("not proof", tool["note"])

    def test_incremental_update_is_detected(self):
        data = make_pdf(["hello"]) + b"\n%%EOF\n"
        self.assertIn("INCREMENTAL_UPDATE", {s["code"] for s in authenticity.inspect_pdf(data, "x")})


class Api(unittest.TestCase):
    def setUp(self):
        self.c = TestClient(app)

    def test_health(self):
        self.assertEqual(self.c.get("/health").json()["status"], "ok")

    def test_analyze_text_pages(self):
        r = self.c.post("/v1/analyze", json={"caseId": "X", "documents": SAMPLE["documents"]})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json()["score"], 72)

    def test_analyze_real_pdf_upload(self):
        pdf = make_pdf(["Fire Safety Certificate (NOC): Valid till 2027-03-31"])
        docs = SAMPLE["documents"] + [{"type": "fire_safety_certificate", "name": "noc.pdf",
                                       "contentBase64": base64.b64encode(pdf).decode()}]
        body = self.c.post("/v1/analyze", json={"caseId": "X", "documents": docs}).json()
        self.assertEqual(body["blocking"], [])
        noc = next(d for d in body["documents"] if d["type"] == "fire_safety_certificate")
        self.assertEqual((noc["mime"], noc["pages"]), ("application/pdf", 1))
        self.assertEqual(len(noc["sha256"]), 64)

    def test_rejects_files_that_only_pretend_to_be_pdfs(self):
        fake = base64.b64encode(b"MZ this is an executable").decode()
        r = self.c.post("/v1/analyze", json={"caseId": "X", "documents": [
            {"type": "fire_safety_certificate", "name": "noc.pdf", "contentBase64": fake}]})
        self.assertEqual(r.status_code, 415)

    def test_monitor(self):
        r = self.c.post("/v1/monitor", json={"asOf": "2026-10-31", "institutions": [
            {"id": "I1", "name": "S", "profile": {"fire_noc_valid_till": "2026-10-20"}}]})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json()["results"][0]["checks"][1]["status"], "breach")


if __name__ == "__main__":
    unittest.main()
