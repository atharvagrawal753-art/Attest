"""Attest document-intelligence and rule engine (FastAPI).

Called only by the Node.js gateway. If INTERNAL_KEY is set, every /v1 call must carry it.
"""
from __future__ import annotations

import base64
import binascii
import hashlib
import hmac
import os
from datetime import date
from typing import Any, Dict, List, Optional

from fastapi import Depends, FastAPI, Header, HTTPException
from pydantic import BaseModel, Field

import authenticity
import extract
import rules as rule_engine

VERSION = "1.0.0"
MAX_DOC_BYTES = 10 * 1024 * 1024
INTERNAL_KEY = os.environ.get("INTERNAL_KEY", "")

app = FastAPI(title="Attest Engine", version=VERSION, docs_url=None, redoc_url=None)


def require_key(x_internal_key: str = Header(default="")) -> None:
    if INTERNAL_KEY and not hmac.compare_digest(x_internal_key.encode(), INTERNAL_KEY.encode()):
        raise HTTPException(status_code=401, detail="Invalid internal key")


class DocumentIn(BaseModel):
    type: str = Field(pattern=r"^[a-z_]{3,40}$")
    name: Optional[str] = None
    pages: Optional[List[str]] = None            # already-extracted text (synthetic samples)
    contentBase64: Optional[str] = None          # raw file bytes (uploaded PDFs / images)


class AnalyzeIn(BaseModel):
    caseId: str
    documents: List[DocumentIn] = Field(min_length=1, max_length=12)


class InstitutionIn(BaseModel):
    id: str
    name: str
    profile: Dict[str, Any] = {}


class MonitorIn(BaseModel):
    institutions: List[InstitutionIn] = Field(min_length=1, max_length=500)
    asOf: Optional[date] = None


@app.get("/health")
def health() -> Dict[str, Any]:
    return {"status": "ok", "service": "engine", "version": VERSION,
            "rulesVersion": rule_engine.load_rules()["version"],
            "pdfTextLayer": extract.pymupdf is not None}


@app.get("/v1/rules", dependencies=[Depends(require_key)])
def get_rules() -> Dict[str, Any]:
    return rule_engine.load_rules()


@app.post("/v1/analyze", dependencies=[Depends(require_key)])
def analyze(body: AnalyzeIn) -> Dict[str, Any]:
    prepared: List[Dict[str, Any]] = []
    summaries: List[Dict[str, Any]] = []
    signals: List[Dict[str, str]] = []

    for doc in body.documents:
        notes: List[str] = []
        mime = "text/plain"
        if doc.contentBase64:
            try:
                raw = base64.b64decode(doc.contentBase64, validate=True)
            except (binascii.Error, ValueError):
                raise HTTPException(status_code=422, detail=f"Document '{doc.type}' is not valid base64")
            if len(raw) > MAX_DOC_BYTES:
                raise HTTPException(status_code=413, detail=f"Document '{doc.type}' is too large")
            detected = extract.sniff_mime(raw)
            if detected is None:
                raise HTTPException(status_code=415, detail=f"Document '{doc.type}' is not a PDF, JPG or PNG")
            mime = detected
            pages, notes = extract.extract_pages(raw)
            signals += authenticity.inspect_pdf(raw, doc.type)
            digest = hashlib.sha256(raw).hexdigest()
        else:
            pages = doc.pages or []
            digest = hashlib.sha256("\n".join(pages).encode()).hexdigest()
        prepared.append({"type": doc.type, "pages": pages})
        summaries.append({"type": doc.type, "name": doc.name, "mime": mime, "sha256": digest,
                          "pages": len(pages), "notes": notes})

    result = rule_engine.analyse_documents(prepared)
    result.update({
        "caseId": body.caseId,
        "documents": summaries,
        "signals": signals,
        "engine": {"version": VERSION, "rulesVersion": rule_engine.load_rules()["version"]},
    })
    return result


@app.post("/v1/monitor", dependencies=[Depends(require_key)])
def monitor(body: MonitorIn) -> Dict[str, Any]:
    rules = rule_engine.load_rules()
    as_of = body.asOf or date.today()
    results = [rule_engine.monitor_institution(i.model_dump(), as_of, rules) for i in body.institutions]
    return {"asOf": as_of.isoformat(), "rulesVersion": rules["version"], "results": results}
