"""Text extraction for uploaded documents.

PDFs with a text layer are read with PyMuPDF. Scanned pages and images need an OCR backend
(pytesseract or PaddleOCR); when none is installed the page is reported as "needs_ocr"
instead of being silently ignored.
"""
from __future__ import annotations

import io
from typing import List, Tuple

try:  # PyMuPDF is optional so the rest of the engine still runs without it.
    import pymupdf  # type: ignore
except Exception:  # pragma: no cover
    pymupdf = None

MAGIC = {
    b"%PDF": "application/pdf",
    b"\xff\xd8\xff": "image/jpeg",
    b"\x89PNG": "image/png",
}


def sniff_mime(data: bytes) -> str | None:
    """Decide the real file type from its first bytes, never from the file name."""
    for magic, mime in MAGIC.items():
        if data.startswith(magic):
            return mime
    return None


def _ocr_image(data: bytes) -> str | None:
    try:
        import pytesseract  # type: ignore
        from PIL import Image  # type: ignore

        return pytesseract.image_to_string(Image.open(io.BytesIO(data)))
    except Exception:
        return None


def extract_pages(data: bytes) -> Tuple[List[str], List[str]]:
    """Return (pages, notes). Each page is plain text; notes explain anything skipped."""
    mime = sniff_mime(data)
    notes: List[str] = []
    if mime == "application/pdf":
        if pymupdf is None:
            return [], ["PyMuPDF is not installed, so the PDF text layer could not be read."]
        pages: List[str] = []
        with pymupdf.open(stream=data, filetype="pdf") as doc:
            for index, page in enumerate(doc, start=1):
                text = page.get_text().strip()
                if not text:
                    notes.append(f"Page {index} has no text layer (scanned page); OCR is required.")
                pages.append(text)
        return pages, notes
    if mime in ("image/jpeg", "image/png"):
        text = _ocr_image(data)
        if text is None:
            return [], ["Image uploaded; no OCR backend installed, so no text was read."]
        return [text], notes
    return [], ["Unsupported file type."]
