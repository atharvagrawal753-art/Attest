"""Authenticity signals for PDF files.

These are *signals for a person to examine*, never proof of fraud. The checks read the raw
file, so they work without any PDF library.
"""
from __future__ import annotations

import re
from datetime import datetime, timedelta
from typing import Dict, List, Optional

EDITING_TOOLS = re.compile(r"photoshop|illustrator|canva|ilovepdf|smallpdf|sejda|pdfescape|gimp", re.I)
NOTE = "A signal for a reviewer to examine; it is not proof of fraud."


def _pdf_date(raw: str) -> Optional[datetime]:
    m = re.match(r"D:(\d{4})(\d{2})?(\d{2})?(\d{2})?(\d{2})?(\d{2})?", raw)
    if not m:
        return None
    parts = [int(g) if g else d for g, d in zip(m.groups(), (1970, 1, 1, 0, 0, 0))]
    try:
        return datetime(*parts)
    except ValueError:
        return None


def _info(data: bytes, key: str) -> Optional[str]:
    m = re.search(rb"/" + key.encode() + rb"\s*\(([^)]*)\)", data)
    return m.group(1).decode("latin-1", "replace") if m else None


def inspect_pdf(data: bytes, doc_type: str) -> List[Dict[str, str]]:
    if not data.startswith(b"%PDF"):
        return []
    signals: List[Dict[str, str]] = []

    revisions = len(re.findall(rb"%%EOF", data))
    if revisions > 1:
        signals.append({
            "code": "INCREMENTAL_UPDATE", "severity": "low", "doc": doc_type,
            "message": f"The PDF was saved {revisions} times (incremental updates). Content may have been changed after first export.",
            "note": NOTE,
        })

    producer, creator = _info(data, "Producer"), _info(data, "Creator")
    for tool in filter(None, (producer, creator)):
        if EDITING_TOOLS.search(tool):
            signals.append({
                "code": "EDITING_TOOL", "severity": "low", "doc": doc_type,
                "message": f"The file metadata names a graphics or online editing tool: {tool}.",
                "note": NOTE,
            })
            break

    created, modified = _info(data, "CreationDate"), _info(data, "ModDate")
    if created and modified:
        c, m = _pdf_date(created), _pdf_date(modified)
        if c and m and m - c > timedelta(days=1):
            signals.append({
                "code": "MODIFIED_AFTER_CREATION", "severity": "medium", "doc": doc_type,
                "message": f"The file was modified {(m - c).days} days after it was created.",
                "note": NOTE,
            })

    if not (producer or creator or created or modified):
        signals.append({
            "code": "METADATA_STRIPPED", "severity": "low", "doc": doc_type,
            "message": "The PDF carries no producer or date metadata.",
            "note": NOTE,
        })
    return signals
