"""Cross-document scrutiny and compliance-monitoring rule engine.

Everything that decides a verdict lives in rules.json. This module only interprets it, so a
reviewer can change a threshold without touching code.
"""
from __future__ import annotations

import json
import os
import re
from datetime import date, datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

RULES_PATH = Path(os.environ.get("RULES_FILE") or Path(__file__).with_name("rules.json"))
DASH = "–"
STATUS_LABEL = {"ok": "Match", "bad": "Conflict", "miss": "Missing"}
POSITIVE_ATTACHMENT = re.compile(r"^(attached|enclosed|valid|yes)\b", re.I)


def load_rules(path: Path = RULES_PATH) -> Dict[str, Any]:
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


# --------------------------------------------------------------------------- scrutiny
def _normalise(kind: str, raw: Optional[str]) -> Optional[Any]:
    if raw is None:
        return None
    value = raw.strip()
    if kind == "int":
        m = re.search(r"\d+", value)
        return int(m.group()) if m else None
    return re.sub(r"[^\w]+", " ", value.casefold()).strip()


def _read_field(field: Dict[str, Any], doc_type: str, pages: List[str]) -> Optional[Dict[str, Any]]:
    pattern = field.get("patterns", {}).get(doc_type)
    if not pattern:
        return None
    rx = re.compile(pattern, re.I)
    for number, text in enumerate(pages, start=1):
        m = rx.search(text or "")
        if m:
            return {"value": m.group(1).strip(), "page": number}
    return None


def _field_status(field: Dict[str, Any], found: Dict[str, Dict[str, Any]],
                  doc_types: set, not_attached: re.Pattern) -> str:
    present = {doc: f for doc, f in found.items() if f}
    if field["kind"] == "attachment":
        provider = field.get("satisfied_by_document")
        if provider and provider in doc_types:
            return "ok"
        values = [f["value"] for f in present.values()]
        if any(not_attached.match(v) for v in values):
            return "miss"
        return "ok" if any(POSITIVE_ATTACHMENT.match(v) for v in values) else "miss"
    distinct = {_normalise(field["kind"], f["value"]) for f in present.values()}
    distinct.discard(None)
    if not distinct:
        return "miss"
    return "bad" if len(distinct) > 1 else "ok"


def _join(parts: List[str]) -> str:
    if len(parts) <= 2:
        return " and ".join(parts)
    return ", ".join(parts[:-1]) + " and " + parts[-1]


def _evidence(fields: List[Dict[str, Any]], labels: Dict[str, str]) -> str:
    sentences: List[str] = []
    for f in fields:
        if f["status"] == "bad":
            parts = [f"{v['value']} on the {labels.get(doc, doc)} (page {v['page']})"
                     for doc, v in f["values"].items()]
            sentences.append(f"{f['label'].lower()} read as {_join(parts)}.")
        elif f["status"] == "miss":
            sentences.append(f"{f['label']} is required by the checklist but not attached."
                             if f.get("mandatory") else f"{f['label']} could not be found in any document.")
    if not sentences:
        return "Evidence: all fields agree across the documents and every mandatory document is attached."
    sentences = [s if i == 0 else s[0].upper() + s[1:] for i, s in enumerate(sentences)]
    return "Evidence: " + " ".join(sentences)


def _evaluate_scrutiny_rule(rule: Dict[str, Any], by_key: Dict[str, Dict[str, Any]]) -> Dict[str, str]:
    kind = rule["type"]
    if kind == "field_status":
        f = by_key[rule["field"]]
        result = {"ok": "Pass", "bad": "Review", "miss": "Missing"}[f["status"]]
        detail = {"Pass": f"{f['label']} agrees in every document.",
                  "Review": f"{f['label']} differs between documents.",
                  "Missing": f"{f['label']} was not found."}[result]
        return {"result": result, "detail": detail}
    if kind == "min_value":
        f = by_key[rule["field"]]
        if f["status"] == "miss":
            return {"result": "Missing", "detail": f"{f['label']} was not found."}
        if f["status"] == "bad":
            return {"result": "Review", "detail": f"{f['label']} differs between documents, so the minimum cannot be confirmed."}
        value = next(_normalise("int", v["value"]) for v in f["values"].values())
        if value is not None and value >= rule["min"]:
            return {"result": "Pass", "detail": f"{f['label']} is {value}, minimum {rule['min']}."}
        return {"result": "Fail", "detail": f"{f['label']} is {value}, below the minimum of {rule['min']}."}
    if kind == "all_mandatory_attached":
        missing = [f["label"] for f in by_key.values() if f.get("mandatory") and f["status"] != "ok"]
        if missing:
            return {"result": "Missing", "detail": "Not attached: " + ", ".join(missing) + "."}
        return {"result": "Pass", "detail": "Every mandatory document is attached."}
    raise ValueError(f"Unknown scrutiny rule type: {kind}")


def analyse_documents(documents: List[Dict[str, Any]], rules: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """documents: [{"type": str, "pages": [str, ...]}]. Returns the full scrutiny result."""
    rules = rules or load_rules()
    cfg = rules["scrutiny"]
    labels = cfg["document_labels"]
    not_attached = re.compile(cfg["not_attached_pattern"], re.I)
    pages_by_type = {d["type"]: d.get("pages", []) for d in documents}
    doc_types = set(pages_by_type)

    fields: List[Dict[str, Any]] = []
    for spec in cfg["fields"]:
        found = {doc: _read_field(spec, doc, pages) for doc, pages in pages_by_type.items()}
        values = {doc: f for doc, f in found.items() if f}
        status = _field_status(spec, found, doc_types, not_attached)
        cells = [(found.get(col) or {}).get("value", DASH) for col in cfg["columns"]]
        fields.append({
            "key": spec["key"], "label": spec["label"], "kind": spec["kind"],
            "mandatory": bool(spec.get("mandatory")),
            "cells": cells, "status": status, "statusLabel": STATUS_LABEL[status],
            "values": values,
        })
    by_key = {f["key"]: f for f in fields}

    rule_results: List[Dict[str, Any]] = []
    blocking: List[Dict[str, str]] = []
    earned = total = 0.0
    for rule in cfg["rules"]:
        outcome = _evaluate_scrutiny_rule(rule, by_key)
        weight = rule.get("weight", 1)
        total += weight
        earned += weight * cfg["credit"][outcome["result"]]
        rule_results.append({"id": rule["id"], "title": rule["title"], "result": outcome["result"],
                             "detail": outcome["detail"], "weight": weight,
                             "blocking": bool(rule.get("blocking"))})
        if rule.get("blocking") and outcome["result"] in ("Missing", "Fail"):
            blocking.append({"ruleId": rule["id"], "reason": outcome["detail"]})

    count = lambda name: sum(1 for r in rule_results if r["result"] == name)
    summary = f"{count('Pass')} passed, {count('Review')} conflict, {count('Missing')} missing"
    if count("Fail"):
        summary += f", {count('Fail')} failed"

    return {
        "fields": fields,
        "rules": rule_results,
        "score": round(100 * earned / total) if total else 0,
        "evidence": _evidence(fields, labels),
        "summary": summary,
        "blocking": blocking,
    }


# ------------------------------------------------------------------------- monitoring
_DOWN = {"critical": "high", "high": "medium", "medium": "low", "low": "low"}


def _as_date(raw: Any) -> Optional[date]:
    if isinstance(raw, date):
        return raw
    try:
        return datetime.strptime(str(raw)[:10], "%Y-%m-%d").date()
    except (TypeError, ValueError):
        return None


def _evaluate_monitoring_rule(rule: Dict[str, Any], profile: Dict[str, Any], as_of: date) -> Dict[str, Any]:
    kind = rule["type"]
    status, detail, value = "unknown", "No data supplied for this check.", None
    if kind == "ratio_max":
        num, den = profile.get(rule["numerator"]), profile.get(rule["denominator"])
        if isinstance(num, (int, float)) and isinstance(den, (int, float)):
            if den == 0:
                status, detail = "breach", "No faculty on record."
            else:
                value = round(num / den, 1)
                status = "compliant" if value <= rule["max"] else "breach"
                detail = f"{value} students per faculty member against a limit of {rule['max']}."
    elif kind == "expiry":
        d = _as_date(profile.get(rule["field"]))
        if d:
            left = (d - as_of).days
            value = left
            if left < 0:
                status, detail = "breach", f"Expired {abs(left)} day(s) ago."
            elif left <= rule["warn_days"]:
                status, detail = "warning", f"Expires in {left} day(s)."
            else:
                status, detail = "compliant", f"Valid for another {left} day(s)."
    elif kind == "min_value":
        v = profile.get(rule["field"])
        if isinstance(v, (int, float)):
            value = v
            status = "compliant" if v >= rule["min"] else "breach"
            detail = f"{v} against a minimum of {rule['min']}."
    elif kind == "boolean_true":
        v = profile.get(rule["field"])
        if isinstance(v, bool):
            status = "compliant" if v else "breach"
            detail = "Filed." if v else "Not filed."
    else:
        raise ValueError(f"Unknown monitoring rule type: {kind}")

    severity = rule["severity"]
    if status == "warning":
        severity = _DOWN[severity]
    elif status == "unknown":
        severity = "low"
    elif status == "compliant":
        severity = None
    return {"ruleId": rule["id"], "title": rule["title"], "status": status,
            "severity": severity, "detail": detail, "value": value, "weight": rule.get("weight", 1)}


def monitor_institution(institution: Dict[str, Any], as_of: Optional[date] = None,
                        rules: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    rules = rules or load_rules()
    cfg = rules["monitoring"]
    as_of = as_of or date.today()
    profile = institution.get("profile", {})
    checks = [_evaluate_monitoring_rule(r, profile, as_of) for r in cfg["rules"]]
    total = sum(c["weight"] for c in checks)
    earned = sum(c["weight"] * cfg["credit"][c["status"]] for c in checks)
    findings = [
        {**c, "message": f"{institution.get('name', institution.get('id'))}: {c['title']}. {c['detail']}"}
        for c in checks if c["status"] != "compliant"
    ]
    return {
        "institutionId": institution.get("id"),
        "name": institution.get("name"),
        "asOf": as_of.isoformat(),
        "complianceIndex": round(100 * earned / total) if total else 0,
        "checks": checks,
        "findings": findings,
    }
