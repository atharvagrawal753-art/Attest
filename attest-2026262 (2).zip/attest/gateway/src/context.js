'use strict';
const { Store } = require('./store');
const { AuditLog } = require('./audit');
const { AlertCenter } = require('./alerts');
const { createServices } = require('./services');
const { seedIfEmpty } = require('./seed');

function createContext(config, overrides = {}) {
  const ctx = { config };
  ctx.store = new Store(config.dataDir);
  ctx.audit = new AuditLog(config.dataDir);
  ctx.services = overrides.services || createServices(config);
  ctx.alerts = new AlertCenter(ctx);
  seedIfEmpty(ctx);
  return ctx;
}
module.exports = { createContext };
