'use strict';
const crypto = require('node:crypto');
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');

const { AppError } = require('./errors');
const auth = require('./auth');
const cases = require('./cases');
const wf = require('./workflow');
const jobs = require('./jobs');
const { cspDirectives } = require('./csp');

const VERSION = '1.0.0';
const ah = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const str = (v, name, { min = 1, max = 200 } = {}) => {
  if (typeof v !== 'string' || v.trim().length < min || v.length > max) {
    throw new AppError(400, 'VALIDATION', `${name} must be ${min} to ${max} characters.`);
  }
  return v.trim();
};

function createApp(ctx) {
  const { config } = ctx;
  const app = express();
  const guard = new auth.LoginGuard();
  const needUser = auth.authenticate(ctx);
  const perm = auth.requirePermission;

  app.disable('x-powered-by');
  if (config.trustProxy) app.set('trust proxy', config.trustProxy);
  app.use(helmet({
    contentSecurityPolicy: { useDefaults: false, directives: cspDirectives(config) },
    crossOriginEmbedderPolicy: false, hsts: config.production,
  }));

  const limiter = (limit, windowMs, message) => rateLimit({
    windowMs, limit, standardHeaders: 'draft-7', legacyHeaders: false,
    handler: (_req, res) => res.status(429).json({ error: { code: 'RATE_LIMITED', message } }),
  });
  const api = express.Router();
  api.use((_req, res, next) => { res.set('Cache-Control', 'no-store'); next(); });
  api.use(limiter(config.rateLimitPerMin, 60000, 'Too many requests. Please slow down.'));
  api.use(express.json({ limit: '100kb' }));

  // ---------------------------------------------------------------- public endpoints
  api.get('/health', (_req, res) => res.json({ status: 'ok', service: 'gateway', version: VERSION, time: new Date().toISOString() }));

  api.get('/meta', (_req, res) => res.json({
    version: VERSION, ps: config.ps, demoMode: config.demoMode, demoCaseId: config.demoCaseId,
    workflow: Object.fromEntries(Object.entries(wf.STATES).map(([k, v]) => [k, { label: v.label, slaDays: v.slaDays || null, terminal: !!v.terminal }])),
  }));

  api.post('/auth/login', limiter(10, 15 * 60000, 'Too many sign-in attempts. Try again later.'), ah(async (req, res) => {
    const username = str(req.body?.username, 'username', { max: 60 }).toLowerCase();
    const password = str(req.body?.password, 'password', { max: 200 });
    guard.check(username);
    const user = ctx.store.data.users.find((u) => u.username === username && u.active !== false);
    const ok = user ? auth.verifyPassword(password, user.passwordHash) : (auth.verifyPassword(password, 'scrypt$00$00'), false);
    if (!ok) {
      guard.failure(username);
      ctx.audit.append({ action: 'LOGIN_FAILED', details: { username } });
      throw new AppError(401, 'BAD_CREDENTIALS', 'Incorrect username or password.');
    }
    guard.success(username);
    ctx.audit.append({ actor: user, action: 'LOGIN', details: {} });
    res.json({ token: auth.signToken(config, user), user: auth.publicUser(user) });
  }));

  api.post('/session/demo', limiter(60, 15 * 60000, 'Too many demo sessions.'), ah(async (_req, res) => {
    if (!config.demoMode) throw new AppError(404, 'NOT_FOUND', 'Demo sessions are disabled.');
    const user = ctx.store.data.users.find((u) => u.username === 'demo.reviewer');
    if (!user) throw new AppError(404, 'NOT_FOUND', 'Demo user is not available.');
    res.json({ token: auth.signToken(config, user), user: auth.publicUser(user), demo: true });
  }));

  // live alert stream: authenticated by a one-use ticket (EventSource cannot send headers)
  api.get('/alerts/stream', (req, res) => {
    const user = ctx.alerts.consumeTicket(String(req.query.ticket || ''));
    if (!user || !auth.can(user, 'alert:read')) return res.status(401).json({ error: { code: 'TICKET_INVALID', message: 'Stream ticket is invalid or expired.' } });
    res.set({ 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache, no-transform', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
    res.flushHeaders();
    res.write(': connected\n\n');
    ctx.alerts.addClient(res);
    const beat = setInterval(() => res.write(': keep-alive\n\n'), 25000);
    req.on('close', () => { clearInterval(beat); ctx.alerts.removeClient(res); });
  });

  // ------------------------------------------------------------ authenticated endpoints
  api.use(needUser);

  api.get('/auth/me', (req, res) => res.json({ user: auth.publicUser(req.user) }));
  api.post('/stream-ticket', perm('alert:read'), (req, res) => res.json({ ticket: ctx.alerts.issueTicket(req.user), expiresInSeconds: 30 }));

  api.get('/cases', (req, res) => {
    if (!auth.can(req.user, 'case:read') && !auth.can(req.user, 'case:read:own')) throw new AppError(403, 'FORBIDDEN', 'Your role is not permitted to do this.');
    res.json({ items: cases.listFor(ctx, req.user) });
  });

  api.post('/cases', perm('case:create'), ah(async (req, res) => {
    const institutionName = req.user.role === 'INSTITUTION' ? '-' : str(req.body?.institutionName, 'institutionName', { max: 120 });
    const programme = str(req.body?.programme, 'programme', { max: 120 });
    res.status(201).json(cases.view(cases.createCase(ctx, req.user, { institutionName, programme })));
  }));

  const caseRoute = (permission, handler) => [perm(permission), ah(async (req, res) => handler(req, res, cases.findCase(ctx, req.params.id, req.user)))];
  const readCase = (req) => (auth.can(req.user, 'case:read') ? 'case:read' : 'case:read:own');

  api.get('/cases/:id', (req, res, next) => perm(readCase(req))(req, res, (e) => e ? next(e)
    : ah(async () => res.json(cases.view(cases.findCase(ctx, req.params.id, req.user))))(req, res, next)));

  api.get('/cases/:id/preview', ...caseRoute('case:read', async (_req, res, c) => res.json(await cases.preview(ctx, c))));

  api.get('/cases/:id/audit', ...caseRoute('audit:read', async (req, res, c) => {
    const limit = Math.min(100, parseInt(req.query.limit, 10) || 20);
    res.json({ items: ctx.audit.list({ caseId: c.id, limit }) });
  }));

  api.put('/cases/:id/documents/:type', perm('document:upload'),
    express.raw({ type: () => true, limit: config.maxUploadBytes }),
    ah(async (req, res) => {
      const c = cases.findCase(ctx, req.params.id, req.user);
      const doc = cases.addDocument(ctx, c, req.params.type, req.body, req.query.filename, req.user);
      res.status(201).json({ type: req.params.type, name: doc.name, mime: doc.mime, size: doc.size, sha256: doc.sha256, state: c.state });
    }));

  api.post('/cases/:id/scrutiny', ...caseRoute('scrutiny:run', async (req, res, c) => {
    const analysis = await cases.runScrutiny(ctx, c, req.user);
    jobs.runEscalations(ctx).catch(() => {}); // notify straight away instead of waiting for the next tick
    res.json({ ...analysis, state: c.state, stateLabel: wf.STATES[c.state].label });
  }));

  api.post('/cases/:id/forward', ...caseRoute('case:advance', async (req, res, c) => res.json(cases.forward(ctx, c, req.user))));

  api.post('/cases/:id/decision', ...caseRoute('case:read', async (req, res, c) => {
    const decision = str(req.body?.decision, 'decision', { max: 40 });
    const reason = str(req.body?.reason, 'reason', { min: 3, max: 500 });
    res.json({ ok: true, ...(await cases.decide(ctx, c, { decision, reason, override: req.body?.override === true }, req.user)) });
  }));

  // ------------------------------------------------------------------------- alerts
  api.get('/alerts', perm('alert:read'), (req, res) => res.json({
    items: ctx.alerts.list({ status: req.query.status, severity: req.query.severity, caseId: req.query.caseId, limit: parseInt(req.query.limit, 10) || 50 }),
  }));
  api.post('/alerts/:id/ack', perm('alert:ack'), (req, res) => res.json(ctx.alerts.view(ctx.alerts.acknowledge(req.params.id, req.user))));

  // ------------------------------------------------------------ monitoring, dashboard
  api.get('/monitoring/institutions', perm('monitoring:read'), (_req, res) => res.json(ctx.store.data.monitoring || { results: [], lastRunAt: null }));
  api.post('/monitoring/run', perm('monitoring:run'), ah(async (req, res) => res.json(await jobs.runMonitoring(ctx, req.user))));

  api.get('/dashboard', perm('dashboard:read'), (_req, res) => {
    const all = ctx.store.data.cases;
    const byState = {};
    for (const c of all) byState[c.state] = (byState[c.state] || 0) + 1;
    const slas = all.map((c) => wf.slaStatus(c)).filter(Boolean);
    const active = ctx.alerts.all.filter((a) => a.status !== 'resolved');
    const bySeverity = {};
    for (const a of active) bySeverity[a.severity] = (bySeverity[a.severity] || 0) + 1;
    const results = ctx.store.data.monitoring?.results || [];
    res.json({
      cases: { total: all.length, byState },
      sla: { atRisk: slas.filter((s) => s.ratio >= 0.8 && s.ratio < 1).length, breached: slas.filter((s) => s.ratio >= 1).length },
      alerts: { active: active.length, bySeverity, escalated: active.filter((a) => a.level >= 2).length },
      compliance: { lastRunAt: ctx.store.data.monitoring?.lastRunAt || null,
        averageIndex: results.length ? Math.round(results.reduce((n, r) => n + r.complianceIndex, 0) / results.length) : null },
    });
  });

  api.get('/audit', perm('audit:read'), (req, res) => res.json({ items: ctx.audit.list({ caseId: req.query.caseId, action: req.query.action, limit: parseInt(req.query.limit, 10) || 50 }) }));
  api.get('/audit/verify', perm('audit:read'), (_req, res) => res.json(ctx.audit.verify()));
  api.get('/system/status', perm('dashboard:read'), ah(async (_req, res) => res.json({
    gateway: { up: true, language: 'Node.js', version: VERSION }, ...(await ctx.services.status()), demoMode: config.demoMode, cspMode: config.cspMode })));

  api.use((_req, _res, next) => next(new AppError(404, 'NOT_FOUND', 'Unknown endpoint.')));
  app.use('/api', api);

  // ---------------------------------------- internal (called by the PHP portal only)
  app.get('/internal/public/applications/:ref', (req, res) => {
    const given = Buffer.from(req.get('x-internal-key') || '');
    const want = Buffer.from(config.internalKey);
    if (given.length !== want.length || !crypto.timingSafeEqual(given, want)) return res.status(401).json({ error: 'invalid internal key' });
    const c = ctx.store.data.cases.find((x) => x.id === String(req.params.ref).toUpperCase());
    if (!c) return res.status(404).json({ error: 'not found' });
    res.json(wf.publicStatus(c));
  });

  // ------------------------------------------------------------------ front end
  app.use(express.static(config.publicDir, { index: 'index.html', maxAge: config.production ? '1h' : 0 }));

  app.use((err, _req, res, _next) => {
    if (err instanceof AppError) return res.status(err.status).json({ error: { code: err.code, message: err.message, ...err.extra } });
    if (err.type === 'entity.too.large') return res.status(413).json({ error: { code: 'TOO_LARGE', message: 'The request body is too large.' } });
    if (err.type === 'entity.parse.failed') return res.status(400).json({ error: { code: 'BAD_JSON', message: 'The request body is not valid JSON.' } });
    console.error('[gateway] unexpected error:', err);
    res.status(500).json({ error: { code: 'INTERNAL', message: 'Something went wrong on our side.' } });
  });
  return app;
}

module.exports = { createApp, VERSION };
