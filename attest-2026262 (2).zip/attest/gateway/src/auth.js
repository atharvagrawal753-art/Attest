'use strict';
const crypto = require('node:crypto');
const jwt = require('jsonwebtoken');
const { AppError } = require('./errors');

const ROLES = ['INSTITUTION', 'SCRUTINY_OFFICER', 'EXPERT_COMMITTEE', 'REGIONAL_OFFICER', 'ADMIN'];

/** Role -> permissions. Checked on every protected route; the front end is never trusted. */
const PERMISSIONS = {
  INSTITUTION: ['case:create', 'document:upload', 'case:read:own'],
  SCRUTINY_OFFICER: ['case:read', 'document:upload', 'scrutiny:run', 'case:advance', 'decision:correction',
    'alert:read', 'alert:ack', 'audit:read'],
  EXPERT_COMMITTEE: ['case:read', 'case:advance', 'decision:approve', 'decision:reject', 'decision:correction',
    'alert:read', 'audit:read'],
  REGIONAL_OFFICER: ['case:read', 'document:upload', 'scrutiny:run', 'case:advance', 'decision:approve',
    'decision:reject', 'decision:correction', 'override:blocking', 'alert:read', 'alert:ack',
    'monitoring:run', 'monitoring:read', 'audit:read', 'dashboard:read'],
  ADMIN: ['*'],
};
// Officers who are not ADMIN also see the dashboard and monitoring results.
for (const r of ['SCRUTINY_OFFICER', 'EXPERT_COMMITTEE']) PERMISSIONS[r].push('dashboard:read', 'monitoring:read');

const can = (user, permission) =>
  !!user && (PERMISSIONS[user.role]?.includes('*') || PERMISSIONS[user.role]?.includes(permission));

// ------------------------------------------------------------------------- passwords
function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(password, salt, 64);
  return `scrypt$${salt.toString('hex')}$${hash.toString('hex')}`;
}

function verifyPassword(password, stored) {
  const [scheme, saltHex, hashHex] = String(stored).split('$');
  if (scheme !== 'scrypt' || !saltHex || !hashHex) return false;
  const expected = Buffer.from(hashHex, 'hex');
  const actual = crypto.scryptSync(password, Buffer.from(saltHex, 'hex'), expected.length);
  return crypto.timingSafeEqual(actual, expected);
}

// ----------------------------------------------------------------------------- tokens
const publicUser = (u) => ({ id: u.id, username: u.username, name: u.name, role: u.role, institutionId: u.institutionId || null });

function signToken(config, user) {
  return jwt.sign({ role: user.role }, config.jwtSecret, {
    algorithm: 'HS256', subject: user.id, expiresIn: `${config.tokenHours}h`, issuer: 'attest-gateway',
  });
}

function authenticate(ctx) {
  return (req, _res, next) => {
    const header = req.get('authorization') || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) return next(new AppError(401, 'UNAUTHENTICATED', 'Sign in to continue.'));
    let claims;
    try {
      claims = jwt.verify(token, ctx.config.jwtSecret, { algorithms: ['HS256'], issuer: 'attest-gateway' });
    } catch {
      return next(new AppError(401, 'TOKEN_INVALID', 'Your session has expired. Please sign in again.'));
    }
    const user = ctx.store.data.users.find((u) => u.id === claims.sub && u.active !== false);
    if (!user) return next(new AppError(401, 'TOKEN_INVALID', 'This account is no longer active.'));
    req.user = user; // role always comes from the database, not from the token
    next();
  };
}

const requirePermission = (permission) => (req, _res, next) =>
  can(req.user, permission) ? next()
    : next(new AppError(403, 'FORBIDDEN', 'Your role is not permitted to do this.', { required: permission }));

// ------------------------------------------------------------------- login throttling
const FAIL_LIMIT = 5;
const LOCK_MS = 15 * 60 * 1000;

class LoginGuard {
  constructor() { this.fails = new Map(); }
  check(username, now = Date.now()) {
    const f = this.fails.get(username);
    if (f && f.lockedUntil > now) {
      throw new AppError(429, 'ACCOUNT_LOCKED', `Too many failed attempts. Try again in ${Math.ceil((f.lockedUntil - now) / 60000)} minute(s).`);
    }
  }
  failure(username, now = Date.now()) {
    const f = this.fails.get(username) || { count: 0, lockedUntil: 0 };
    f.count += 1;
    if (f.count >= FAIL_LIMIT) { f.lockedUntil = now + LOCK_MS; f.count = 0; }
    this.fails.set(username, f);
  }
  success(username) { this.fails.delete(username); }
}

module.exports = { ROLES, PERMISSIONS, can, hashPassword, verifyPassword, signToken, authenticate,
  requirePermission, publicUser, LoginGuard };
