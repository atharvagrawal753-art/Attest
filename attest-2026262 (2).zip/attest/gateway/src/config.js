'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const ROOT = path.resolve(__dirname, '..');

/** Minimal .env loader (no dependency). Real environment variables always win. */
function loadEnvFile(file) {
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^(['"])(.*)\1$/, '$2');
  }
}
loadEnvFile(path.join(ROOT, '.env'));
loadEnvFile(path.join(ROOT, '..', '.env'));

const bool = (v, d) => (v === undefined || v === '' ? d : /^(1|true|yes|on)$/i.test(v));
const int = (v, d) => (Number.isFinite(parseInt(v, 10)) ? parseInt(v, 10) : d);

function load(env = process.env) {
  const nodeEnv = env.NODE_ENV || 'development';
  const production = nodeEnv === 'production';

  let jwtSecret = env.JWT_SECRET;
  if (!jwtSecret) {
    if (production) throw new Error('JWT_SECRET must be set when NODE_ENV=production');
    jwtSecret = crypto.randomBytes(32).toString('hex'); // dev only: sessions end on restart
  }
  if (production && !env.INTERNAL_KEY) throw new Error('INTERNAL_KEY must be set when NODE_ENV=production');
  if (production && !env.ADMIN_PASSWORD) throw new Error('ADMIN_PASSWORD must be set when NODE_ENV=production');

  return {
    ROOT,
    env: nodeEnv,
    production,
    host: env.HOST || '127.0.0.1',
    port: int(env.PORT, 3000),
    trustProxy: env.TRUST_PROXY ? (/^\d+$/.test(env.TRUST_PROXY) ? int(env.TRUST_PROXY, 1) : env.TRUST_PROXY) : false,
    dataDir: path.resolve(env.DATA_DIR || path.join(ROOT, 'data')),
    publicDir: path.join(ROOT, 'public'),
    jwtSecret,
    tokenHours: int(env.TOKEN_HOURS, 8),
    internalKey: env.INTERNAL_KEY || 'dev-internal-key',
    demoMode: bool(env.DEMO_MODE, !production),
    seedDemoUsers: bool(env.SEED_DEMO_USERS, !production),
    devPassword: env.DEV_PASSWORD || 'Attest@2026',
    adminPassword: env.ADMIN_PASSWORD || '',
    cspMode: (env.CSP_MODE || 'relaxed').toLowerCase() === 'strict' ? 'strict' : 'relaxed',
    rateLimitPerMin: int(env.RATE_LIMIT_PER_MIN, 240),
    maxUploadBytes: int(env.MAX_UPLOAD_MB, 10) * 1024 * 1024,
    schedulerSeconds: int(env.SCHEDULER_SECONDS, 60),
    monitorMinutes: int(env.MONITOR_MINUTES, 60),
    demoCaseId: 'AICTE-2026-4839',
    ps: {
      id: '2026262',
      title: 'Integrated AICTE Approval Workflow Automation, Compliance Monitoring and Alert Management System',
    },
    services: {
      engine: env.ENGINE_URL || 'http://127.0.0.1:8001',
      escalation: env.ESCALATION_URL || 'http://127.0.0.1:8002',
      portal: env.PORTAL_URL || 'http://127.0.0.1:8003',
      timeoutMs: int(env.SERVICE_TIMEOUT_MS, 15000),
    },
  };
}

module.exports = { load, ROOT };
