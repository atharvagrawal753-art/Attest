'use strict';
const { AppError } = require('./errors');

// Same matrix as escalation/EscalationService.java. Used only when that service is unreachable,
// so alerts still escalate. tests/escalation-parity checks the two stay in step.
const MATRIX = { critical: [0, 30, 120], high: [0, 240, 1440], medium: [0, 1440, 4320], low: [0, 4320, Infinity] };
const NOTIFY = [['SCRUTINY_OFFICER'], ['SCRUTINY_OFFICER', 'REGIONAL_OFFICER'], ['SCRUTINY_OFFICER', 'REGIONAL_OFFICER', 'MEMBER_SECRETARY']];
const CHANNELS = [['IN_APP'], ['IN_APP', 'EMAIL'], ['IN_APP', 'EMAIL', 'SMS']];

function localEscalation(severity, ageMinutes) {
  const t = MATRIX[severity] || MATRIX.low;
  let level = 1;
  for (let i = 1; i < t.length; i++) if (ageMinutes >= t[i]) level = i + 1;
  const next = level < t.length && Number.isFinite(t[level]) ? Math.ceil(t[level] - ageMinutes) : null;
  return { severity, ageMinutes: Math.floor(ageMinutes), level, notify: NOTIFY[level - 1], channels: CHANNELS[level - 1],
    nextLevelInMinutes: next, source: 'local-fallback' };
}

function createServices(config, fetchImpl = globalThis.fetch) {
  const { engine, escalation, portal, timeoutMs } = config.services;
  const keyHeader = { 'X-Internal-Key': config.internalKey };

  async function request(name, base, path, { method = 'GET', body, headers = {}, timeout = timeoutMs } = {}) {
    let res;
    try {
      res = await fetchImpl(base + path, {
        method, body, headers: { ...keyHeader, ...headers }, signal: AbortSignal.timeout(timeout),
      });
    } catch (e) {
      throw new AppError(503, 'SERVICE_UNAVAILABLE', `The ${name} service is not reachable right now.`, { service: name });
    }
    const text = await res.text();
    let json = null;
    try { json = text ? JSON.parse(text) : null; } catch { /* non-JSON error body */ }
    if (!res.ok) {
      const detail = json?.detail || json?.error || `HTTP ${res.status}`;
      const status = res.status >= 500 ? 502 : 422;
      throw new AppError(status, 'SERVICE_ERROR', typeof detail === 'string' ? detail : JSON.stringify(detail), { service: name });
    }
    return json;
  }

  return {
    engine: {
      analyze: (payload) => request('engine', engine, '/v1/analyze', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload),
      }),
      monitor: (payload) => request('engine', engine, '/v1/monitor', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload),
      }),
    },
    escalation: {
      async evaluate(severity, ageMinutes) {
        try {
          const q = new URLSearchParams({ severity, ageMinutes: String(Math.max(0, Math.floor(ageMinutes))) });
          return { ...(await request('escalation', escalation, `/v1/escalation?${q}`, { timeout: 3000 })), source: 'java-service' };
        } catch {
          return localEscalation(severity, Math.max(0, ageMinutes));
        }
      },
      /** Best effort: a failed notification must never fail the business action that caused it. */
      async dispatch({ alertId, level, severity, subject, body, recipients, channels }) {
        try {
          const form = new URLSearchParams({ alertId, level: String(level), severity, subject, body: body || '' });
          if (recipients) form.set('recipients', recipients.join(','));
          if (channels) form.set('channels', channels.join(','));
          const out = await request('escalation', escalation, '/v1/dispatch', {
            method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: form.toString(), timeout: 3000,
          });
          return { dispatched: true, ...out };
        } catch (e) {
          return { dispatched: false, reason: e.message };
        }
      },
    },
    async status() {
      const probe = async (base, path) => {
        const t0 = Date.now();
        try {
          const r = await fetchImpl(base + path, { signal: AbortSignal.timeout(2000) });
          return { up: r.ok, latencyMs: Date.now() - t0 };
        } catch { return { up: false, latencyMs: null }; }
      };
      const [e, s, p] = await Promise.all([probe(engine, '/health'), probe(escalation, '/health'), probe(portal, '/health')]);
      return { engine: { ...e, language: 'Python' }, escalation: { ...s, language: 'Java' }, portal: { ...p, language: 'PHP' } };
    },
  };
}

module.exports = { createServices, localEscalation };
