'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { hashPassword } = require('./auth');
const { DAY_MS } = require('./workflow');

const daysAgo = (n) => new Date(Date.now() - n * DAY_MS).toISOString();
const dateIn = (n) => new Date(Date.now() + n * DAY_MS).toISOString().slice(0, 10);

function loadSample(config) {
  const file = process.env.SAMPLE_CASE_FILE || path.join(config.ROOT, '..', 'shared', 'sample-case-4839.json');
  return JSON.parse(fs.readFileSync(file, 'utf8'));
}

function seedUsers(ctx) {
  const { config, store } = ctx;
  const users = store.data.users;
  const add = (username, name, role, password, institutionId = null) => {
    if (users.some((u) => u.username === username)) return;
    users.push({ id: `U-${crypto.randomBytes(4).toString('hex')}`, username, name, role, institutionId, active: true, passwordHash: hashPassword(password) });
  };
  if (config.seedDemoUsers) {
    const p = config.devPassword;
    add('admin', 'System Administrator', 'ADMIN', p);
    add('scrutiny.officer', 'A. Sharma (Scrutiny Officer)', 'SCRUTINY_OFFICER', p);
    add('expert.member', 'Dr. R. Iyer (Expert Committee)', 'EXPERT_COMMITTEE', p);
    add('regional.officer', 'S. Verma (Regional Officer)', 'REGIONAL_OFFICER', p);
    add('sample.institution', 'Sample Institute of Technology', 'INSTITUTION', p, 'INST-001');
  } else if (config.adminPassword) {
    add('admin', 'System Administrator', 'ADMIN', config.adminPassword);
  }
  // The demo session user can only be reached through /api/session/demo: its password is never known.
  if (config.demoMode) add('demo.reviewer', 'Demo Reviewer (Regional Officer)', 'REGIONAL_OFFICER', crypto.randomBytes(24).toString('hex'));
}

function seedData(ctx) {
  const { store } = ctx;
  const sample = loadSample(ctx.config);
  const d = store.data;

  d.institutions.push(
    { id: 'INST-001', name: 'Sample Institute of Technology', profile: {
      faculty_count: 64, students_enrolled: 1210, land_area_acres: 5.2, mandatory_disclosure_filed: true,
      fire_noc_valid_till: dateIn(12), accreditation_valid_till: dateIn(400) } },
    { id: 'INST-002', name: 'Demo College of Engineering and Management', profile: {
      faculty_count: 40, students_enrolled: 920, land_area_acres: 2.0, mandatory_disclosure_filed: false,
      fire_noc_valid_till: dateIn(-5), accreditation_valid_till: dateIn(60) } },
    { id: 'INST-003', name: 'Sample Polytechnic', profile: {
      faculty_count: 58, students_enrolled: 1100, land_area_acres: 4.1, mandatory_disclosure_filed: true,
      fire_noc_valid_till: dateIn(300), accreditation_valid_till: dateIn(500) } },
    { id: 'INST-004', name: 'Sample Institute of Pharmacy', profile: {
      faculty_count: 30, students_enrolled: 580, land_area_acres: 3.0, mandatory_disclosure_filed: true,
      fire_noc_valid_till: dateIn(200), accreditation_valid_till: dateIn(25) } },
  );

  const documents = {};
  for (const doc of sample.documents) {
    documents[doc.type] = {
      name: doc.name, mime: 'application/pdf', pages: doc.pages, synthetic: true,
      sha256: crypto.createHash('sha256').update(doc.pages.join('\n')).digest('hex'),
      size: doc.pages.join('\n').length, uploadedAt: new Date().toISOString(),
    };
  }

  const mk = (id, inst, programme, state, entered, docs = {}) => ({
    id, institutionId: inst.id, institutionName: inst.name, programme, state,
    stateEnteredAt: entered, createdAt: entered, documents: docs, analysis: null, decisions: [],
  });
  d.cases.push(
    mk(sample.caseId, d.institutions[0], 'B.Tech (Computer Science and Engineering)', 'SUBMITTED', new Date().toISOString(), documents),
    mk('AICTE-2026-4701', d.institutions[1], 'B.Tech (Mechanical Engineering)', 'SCRUTINY', daysAgo(9)),
    mk('AICTE-2026-4755', d.institutions[2], 'Diploma (Electrical Engineering)', 'EXPERT_REVIEW', daysAgo(13)),
    mk('AICTE-2026-4620', d.institutions[3], 'B.Pharm', 'APPROVED', daysAgo(40)),
  );
}

function seedIfEmpty(ctx) {
  const wasFresh = ctx.store.fresh && ctx.store.data.cases.length === 0;
  if (wasFresh) seedData(ctx);
  seedUsers(ctx);
  ctx.store.flush();
  if (wasFresh) ctx.audit.append({ action: 'SYSTEM_SEEDED', details: { cases: ctx.store.data.cases.length, note: 'Synthetic demonstration data' } });
  if (wasFresh) ctx.audit.append({ action: 'CASE_RECEIVED', caseId: 'AICTE-2026-4839', details: { institution: 'Sample Institute of Technology' } });
}

module.exports = { seedIfEmpty };
