'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const GENESIS = '0'.repeat(64);
const SYSTEM = Object.freeze({ id: 'system', name: 'System', role: 'SYSTEM' });

const digest = (e) =>
  crypto.createHash('sha256')
    .update(JSON.stringify([e.seq, e.ts, e.actor, e.action, e.caseId, e.details, e.prevHash]))
    .digest('hex');

/**
 * Append-only, hash-chained audit trail (one JSON object per line).
 * Every entry stores the hash of the previous one, so editing, deleting or re-ordering any
 * line breaks every hash after it and verify() reports exactly where.
 */
class AuditLog {
  constructor(dir) {
    this.file = path.join(dir, 'audit.jsonl');
    this.entries = [];
    this.corruptLine = null;
    if (fs.existsSync(this.file)) {
      const lines = fs.readFileSync(this.file, 'utf8').split('\n').filter(Boolean);
      lines.forEach((line, i) => {
        try { this.entries.push(JSON.parse(line)); }
        catch { if (this.corruptLine === null) this.corruptLine = i + 1; }
      });
    }
  }

  append({ actor = SYSTEM, action, caseId = null, details = {} }) {
    const last = this.entries[this.entries.length - 1];
    const entry = {
      seq: last ? last.seq + 1 : 1,
      ts: new Date().toISOString(),
      actor: { id: actor.id, name: actor.name, role: actor.role },
      action,
      caseId,
      details,
      prevHash: last ? last.hash : GENESIS,
    };
    entry.hash = digest(entry);
    fs.appendFileSync(this.file, JSON.stringify(entry) + '\n');
    this.entries.push(entry);
    return entry;
  }

  /** Re-reads the file from disk, so tampering after start-up is caught too. */
  verify() {
    let lines = [];
    if (fs.existsSync(this.file)) lines = fs.readFileSync(this.file, 'utf8').split('\n').filter(Boolean);
    let prev = GENESIS;
    for (let i = 0; i < lines.length; i++) {
      let e;
      try { e = JSON.parse(lines[i]); } catch { return { valid: false, entries: lines.length, brokenAtLine: i + 1, reason: 'unreadable entry' }; }
      if (e.seq !== i + 1) return { valid: false, entries: lines.length, brokenAtSeq: e.seq, reason: 'sequence gap or reorder' };
      if (e.prevHash !== prev) return { valid: false, entries: lines.length, brokenAtSeq: e.seq, reason: 'chain link broken' };
      if (digest(e) !== e.hash) return { valid: false, entries: lines.length, brokenAtSeq: e.seq, reason: 'entry content altered' };
      prev = e.hash;
    }
    return { valid: true, entries: lines.length, headHash: prev };
  }

  list({ caseId, limit = 50, action } = {}) {
    let out = this.entries;
    if (caseId) out = out.filter((e) => e.caseId === caseId);
    if (action) out = out.filter((e) => e.action === action);
    return out.slice(-Math.max(1, Math.min(500, limit)));
  }
}

module.exports = { AuditLog, SYSTEM, GENESIS };
