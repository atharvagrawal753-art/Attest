'use strict';
const crypto = require('node:crypto');
const { SYSTEM } = require('./audit');
const { AppError } = require('./errors');

const SEVERITY_RANK = { critical: 4, high: 3, medium: 2, low: 1 };

/**
 * Alert management: raise (de-duplicated), acknowledge, resolve, and push live to browsers
 * over Server-Sent Events. An alert is "active" until it is resolved.
 */
class AlertCenter {
  constructor(ctx) {
    this.ctx = ctx;
    this.clients = new Set();
    this.tickets = new Map();
  }

  get all() { return this.ctx.store.data.alerts; }

  view(a) {
    return { id: a.id, type: a.type, severity: a.severity, status: a.status, message: a.message, caseId: a.caseId,
      institutionId: a.institutionId, createdAt: a.createdAt, occurredAt: a.occurredAt, level: a.level,
      escalatedAt: a.escalatedAt || null, acknowledgedBy: a.acknowledgedBy || null, acknowledgedAt: a.acknowledgedAt || null,
      resolvedAt: a.resolvedAt || null };
  }

  raise({ type, severity, message, caseId = null, institutionId = null, key, occurredAt }) {
    const existing = this.all.find((a) => a.dedupeKey === key && a.status !== 'resolved');
    if (existing) return { alert: existing, created: false };
    const now = new Date().toISOString();
    const alert = {
      id: `ALT-${String(this.ctx.store.nextId('alert')).padStart(6, '0')}`,
      type, severity, status: 'open', message, caseId, institutionId, dedupeKey: key,
      createdAt: now, occurredAt: occurredAt || now, level: 0,
    };
    this.all.push(alert);
    this.ctx.store.save();
    this.ctx.audit.append({ action: 'ALERT_RAISED', caseId, details: { alertId: alert.id, type, severity, message } });
    this.broadcast('alert', this.view(alert));
    return { alert, created: true };
  }

  /** Resolve every active alert whose key starts with `prefix` (optionally keeping one key). */
  resolveByPrefix(prefix, reason, exceptKey = null) {
    let n = 0;
    for (const a of this.all) {
      if (a.status === 'resolved' || !a.dedupeKey.startsWith(prefix) || a.dedupeKey === exceptKey) continue;
      a.status = 'resolved';
      a.resolvedAt = new Date().toISOString();
      a.resolution = reason;
      this.ctx.audit.append({ action: 'ALERT_RESOLVED', caseId: a.caseId, details: { alertId: a.id, reason } });
      this.broadcast('alert-update', this.view(a));
      n += 1;
    }
    if (n) this.ctx.store.save();
    return n;
  }

  acknowledge(id, user) {
    const a = this.all.find((x) => x.id === id);
    if (!a) throw new AppError(404, 'NOT_FOUND', 'No such alert.');
    if (a.status === 'resolved') throw new AppError(409, 'ALERT_RESOLVED', 'This alert is already resolved.');
    if (a.status === 'acknowledged') return a;
    a.status = 'acknowledged';
    a.acknowledgedBy = user.name;
    a.acknowledgedAt = new Date().toISOString();
    this.ctx.store.save();
    this.ctx.audit.append({ actor: user, action: 'ALERT_ACKNOWLEDGED', caseId: a.caseId, details: { alertId: a.id } });
    this.broadcast('alert-update', this.view(a));
    return a;
  }

  list({ status, severity, caseId, limit = 50 } = {}) {
    let out = this.all.slice();
    if (status === 'active') out = out.filter((a) => a.status !== 'resolved');
    else if (status) out = out.filter((a) => a.status === status);
    if (severity) out = out.filter((a) => a.severity === severity);
    if (caseId) out = out.filter((a) => a.caseId === caseId);
    out.sort((a, b) => (SEVERITY_RANK[b.severity] - SEVERITY_RANK[a.severity]) || (Date.parse(b.occurredAt) - Date.parse(a.occurredAt)));
    return out.slice(0, Math.max(1, Math.min(200, limit))).map((a) => this.view(a));
  }

  // ---------------------------------------------------------------- live stream (SSE)
  /** EventSource cannot send headers, so the browser exchanges its token for a one-use ticket. */
  issueTicket(user) {
    const ticket = crypto.randomBytes(24).toString('base64url');
    this.tickets.set(ticket, { userId: user.id, expires: Date.now() + 30000 });
    for (const [t, v] of this.tickets) if (v.expires < Date.now()) this.tickets.delete(t);
    return ticket;
  }

  consumeTicket(ticket) {
    const t = this.tickets.get(ticket);
    this.tickets.delete(ticket);
    if (!t || t.expires < Date.now()) return null;
    return this.ctx.store.data.users.find((u) => u.id === t.userId && u.active !== false) || null;
  }

  addClient(res) { this.clients.add(res); }
  removeClient(res) { this.clients.delete(res); }

  broadcast(event, payload) {
    const frame = `event: ${event}\ndata: ${JSON.stringify(payload)}\n\n`;
    for (const res of this.clients) {
      try { res.write(frame); } catch { this.clients.delete(res); }
    }
  }
}

module.exports = { AlertCenter, SEVERITY_RANK, SYSTEM };
