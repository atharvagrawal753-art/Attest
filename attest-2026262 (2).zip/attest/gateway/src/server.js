'use strict';
const { load } = require('./config');
const { createContext } = require('./context');
const { createApp } = require('./app');
const { startScheduler } = require('./jobs');

const config = load();
const ctx = createContext(config);
const app = createApp(ctx);
startScheduler(ctx);

const server = app.listen(config.port, config.host, () => {
  console.log(`[gateway] Attest listening on http://${config.host}:${config.port}  (demo=${config.demoMode}, csp=${config.cspMode})`);
  if (config.seedDemoUsers) console.log(`[gateway] dev accounts seeded (password from DEV_PASSWORD): admin, scrutiny.officer, expert.member, regional.officer, sample.institution`);
});

const stop = () => { ctx.store.flush(); server.close(() => process.exit(0)); setTimeout(() => process.exit(0), 3000).unref(); };
process.on('SIGINT', stop);
process.on('SIGTERM', stop);
