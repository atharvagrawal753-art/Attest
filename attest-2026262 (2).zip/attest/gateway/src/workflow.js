'use strict';

/**
 * The approval workflow as data plus two pure functions, so it can be tested without a server.
 *
 *   SUBMITTED -> SCRUTINY -> EXPERT_REVIEW -> APPROVED | REJECTED
 *                    \_______ CORRECTION_REQUESTED _______/ (institution resubmits -> SCRUTINY)
 *
 * SLA days are illustrative configuration, not statutory figures.
 */
const STATES = {
  SUBMITTED: { label: 'Application received', slaDays: 2 },
  SCRUTINY: { label: 'Under scrutiny', slaDays: 7 },
  EXPERT_REVIEW: { label: 'With Expert Committee', slaDays: 15 },
  CORRECTION_REQUESTED: { label: 'Corrections requested from institution', slaDays: 30 },
  APPROVED: { label: 'Approved', terminal: true },
  REJECTED: { label: 'Not approved', terminal: true },
};

const DAY_MS = 86400000;
const isTerminal = (state) => !!STATES[state]?.terminal;

/** What the three reviewer buttons mean. `gated` decisions must pass the compliance gate. */
const DECISIONS = {
  Approved: { to: 'APPROVED', permission: 'decision:approve', from: ['SCRUTINY', 'EXPERT_REVIEW'], gated: true },
  Rejected: { to: 'REJECTED', permission: 'decision:reject', from: ['SCRUTINY', 'EXPERT_REVIEW'] },
  'Correction requested': {
    to: 'CORRECTION_REQUESTED', permission: 'decision:correction', from: ['SCRUTINY', 'EXPERT_REVIEW'],
  },
};

function slaStatus(caseObj, now = Date.now()) {
  const def = STATES[caseObj.state];
  if (!def || def.terminal) return null;
  const entered = Date.parse(caseObj.stateEnteredAt);
  const limit = def.slaDays * DAY_MS;
  return {
    state: caseObj.state,
    enteredAt: caseObj.stateEnteredAt,
    dueAt: new Date(entered + limit).toISOString(),
    slaDays: def.slaDays,
    ratio: (now - entered) / limit,
    daysInState: Math.floor((now - entered) / DAY_MS),
  };
}

/**
 * Decide whether a decision may be applied. Returns { ok:true, to } or
 * { ok:false, status, code, message }. Nothing is mutated here.
 */
function planDecision(caseObj, decisionName, { canOverride = false, override = false } = {}) {
  const def = DECISIONS[decisionName];
  if (!def) return { ok: false, status: 400, code: 'BAD_DECISION', message: 'Decision must be Approved, Rejected or Correction requested.' };

  if (isTerminal(caseObj.state)) {
    return { ok: false, status: 409, code: 'CASE_CLOSED', message: `This application is already closed (${STATES[caseObj.state].label}).` };
  }
  if (!caseObj.analysis) {
    return { ok: false, status: 409, code: 'NO_ANALYSIS', message: 'Run the scrutiny first: no compliance report exists for this application yet.' };
  }
  if (!def.from.includes(caseObj.state)) {
    return { ok: false, status: 409, code: 'WRONG_STAGE',
      message: `A decision cannot be recorded while the application is at "${STATES[caseObj.state].label}".` };
  }
  const blocking = caseObj.analysis.blocking || [];
  if (def.gated && blocking.length) {
    if (!override) {
      return { ok: false, status: 409, code: 'COMPLIANCE_GATE',
        message: `Approval blocked by the compliance gate. ${blocking.map((b) => b.reason).join(' ')} Request a correction, or record an authorised override.` };
    }
    if (!canOverride) {
      return { ok: false, status: 403, code: 'OVERRIDE_NOT_PERMITTED', message: 'Only a Regional Officer may override the compliance gate.' };
    }
  }
  return { ok: true, to: def.to, permission: def.permission, overrideUsed: !!(def.gated && blocking.length && override) };
}

function planForward(caseObj) {
  if (caseObj.state !== 'SCRUTINY') {
    return { ok: false, status: 409, code: 'WRONG_STAGE', message: 'Only an application under scrutiny can be forwarded to the Expert Committee.' };
  }
  if (!caseObj.analysis) {
    return { ok: false, status: 409, code: 'NO_ANALYSIS', message: 'Run the scrutiny before forwarding.' };
  }
  if ((caseObj.analysis.blocking || []).length) {
    return { ok: false, status: 409, code: 'COMPLIANCE_GATE', message: 'Resolve the blocking findings before forwarding to the Expert Committee.' };
  }
  return { ok: true, to: 'EXPERT_REVIEW' };
}

function publicStatus(caseObj) {
  const sla = slaStatus(caseObj);
  return {
    reference: caseObj.id,
    institution: caseObj.institutionName,
    stage: caseObj.state,
    stageLabel: STATES[caseObj.state].label,
    outcome: isTerminal(caseObj.state) ? STATES[caseObj.state].label : null,
    lastUpdated: caseObj.stateEnteredAt,
    expectedBy: sla ? sla.dueAt : null,
  };
}

module.exports = { STATES, DECISIONS, DAY_MS, isTerminal, slaStatus, planDecision, planForward, publicStatus };
