'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const hash = (s) => `'sha256-${crypto.createHash('sha256').update(s, 'utf8').digest('base64')}'`;
const decode = (s) => s.replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');

/**
 * relaxed: inline scripts allowed (works everywhere, the default).
 * strict:  only the exact inline scripts/handlers shipped in index.html are allowed, via SHA-256
 *          hashes, so injected script cannot run. Enable with CSP_MODE=strict.
 */
function scriptDirectives(config) {
  if (config.cspMode !== 'strict') return { scriptSrc: ["'self'", "'unsafe-inline'"], scriptSrcAttr: ["'unsafe-inline'"] };
  const html = fs.readFileSync(path.join(config.publicDir, 'index.html'), 'utf8');
  const scripts = [...html.matchAll(/<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/g)].map((m) => hash(m[1]));
  const handlers = [...html.matchAll(/\son[a-z]+="([^"]*)"/g)].map((m) => hash(decode(m[1])));
  return {
    scriptSrc: ["'self'", ...scripts, ...(handlers.length ? ["'unsafe-hashes'", ...handlers] : [])],
    scriptSrcAttr: handlers.length ? ["'unsafe-hashes'", ...handlers] : ["'none'"],
  };
}

function cspDirectives(config) {
  const { scriptSrc, scriptSrcAttr } = scriptDirectives(config);
  return {
    defaultSrc: ["'self'"], scriptSrc, scriptSrcAttr,
    styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
    fontSrc: ["'self'", 'https://fonts.gstatic.com', 'data:'],
    imgSrc: ["'self'", 'data:'], connectSrc: ["'self'"],
    objectSrc: ["'none'"], baseUri: ["'self'"], formAction: ["'self'"], frameAncestors: ["'none'"],
  };
}
module.exports = { cspDirectives };
