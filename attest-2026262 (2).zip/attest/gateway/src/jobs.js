'use strict';
const { STATES, DAY_MS, slaStatus, isTerminal } = require('./workflow');
const { SYSTEM } = require('./audit');

const stateLabel = (s) => STATES[s]?.label || s;

/** Raise one SLA alert per case/stage at the right level, and retire the lower levels. */
function runSlaChecks(ctx, now = Date.now()) {
  let raised = 0;
  for (const c of ctx.store.data.cases) {
    if (isTerminal(c.state)) continue;
    const sla = slaStatus(c, now);
    if (!sla) continue;
    const entered = Date.parse(c.stateEnteredAt);
    const limit = sla.slaDays * DAY_MS;
    const base = `SLA:${c.id}:${c.state}`;
    const label = stateLabel(c.state);

    let level = null;
    if (sla.ratio >= 1.5) level = { n: 'critical', sev: 'critical', at: entered + limit * 1.5, type: 'SLA_CRITICAL',
      msg: `${c.id} (${c.institutionName}) has been at "${label}" for ${sla.daysInState} days; the limit is ${sla.slaDays}. Immediate action required.` };
    else if (sla.ratio >= 1) level = { n: 'breach', sev: 'high', at: entered + limit, type: 'SLA_BREACH',
      msg: `${c.id} (${c.institutionName}) has been at "${label}" for ${sla.daysInState} days; the limit is ${sla.slaDays}.` };
    else if (sla.ratio >= 0.8) level = { n: 'warning', sev: 'medium', at: entered + limit * 0.8, type: 'SLA_WARNING',
      msg: `${c.id} (${c.institutionName}) is due at "${label}" within ${Math.max(0, Math.ceil(sla.slaDays - sla.ratio * sla.slaDays))} day(s); the limit is ${sla.slaDays}.` };
    if (!level) continue;

    const key = `${base}:${level.n}`;
    const { created } = ctx.alerts.raise({ type: level.type, severity: level.sev, message: level.msg, caseId: c.id,
      institutionId: c.institutionId, key, occurredAt: new Date(level.at).toISOString() });
    if (created) { raised += 1; ctx.alerts.resolveByPrefix(`${base}:`, 'Superseded by a higher SLA level', key); }
  }
  return raised;
}

/** Ask the escalation service which level each unattended alert has reached; notify on a rise. */
async function runEscalations(ctx, now = Date.now()) {
  let escalated = 0;
  for (const a of ctx.alerts.all) {
    if (a.status !== 'open') continue; // acknowledged or resolved alerts stop escalating
    const ageMinutes = Math.max(0, (now - Date.parse(a.occurredAt)) / 60000);
    const esc = await ctx.services.escalation.evaluate(a.severity, ageMinutes);
    if (esc.level <= a.level) continue;
    const from = a.level;
    a.level = esc.level;
    a.escalatedAt = new Date().toISOString();
    ctx.store.save();
    const dispatch = await ctx.services.escalation.dispatch({
      alertId: a.id, level: esc.level, severity: a.severity,
      subject: `[Level ${esc.level}] ${a.severity.toUpperCase()} alert ${a.id}`, body: a.message,
    });
    ctx.audit.append({ action: 'ALERT_ESCALATED', caseId: a.caseId,
      details: { alertId: a.id, fromLevel: from, toLevel: esc.level, notify: esc.notify, via: esc.source, dispatched: dispatch.dispatched } });
    ctx.alerts.broadcast('alert-update', ctx.alerts.view(a));
    escalated += 1;
  }
  return escalated;
}

/** Evaluate every institution against the monitoring rules and raise or retire alerts. */
async function runMonitoring(ctx, actor = SYSTEM) {
  const institutions = ctx.store.data.institutions;
  if (!institutions.length) return { checked: 0, raised: 0 };
  const asOf = new Date().toISOString().slice(0, 10);
  const out = await ctx.services.engine.monitor({
    asOf, institutions: institutions.map((i) => ({ id: i.id, name: i.name, profile: i.profile })),
  });
  ctx.store.data.monitoring = { lastRunAt: new Date().toISOString(), rulesVersion: out.rulesVersion, results: out.results };

  let raised = 0;
  for (const r of out.results) {
    for (const c of r.checks) {
      const prefix = `MON:${r.institutionId}:${c.ruleId}:`;
      const key = `${prefix}${c.status}`;
      ctx.alerts.resolveByPrefix(prefix, c.status === 'compliant' ? 'Now compliant' : 'Status changed', key);
      if (c.status !== 'breach' && c.status !== 'warning') continue;
      const { created } = ctx.alerts.raise({
        type: c.status === 'breach' ? 'COMPLIANCE_BREACH' : 'COMPLIANCE_WARNING', severity: c.severity,
        message: `${r.name}: ${c.title}. ${c.detail}`, institutionId: r.institutionId, key,
      });
      if (created) raised += 1;
    }
  }
  ctx.store.save();
  ctx.audit.append({ actor, action: 'MONITORING_RUN', details: { institutions: out.results.length, raised, rulesVersion: out.rulesVersion } });
  return { checked: out.results.length, raised };
}

function startScheduler(ctx, log = console) {
  const guard = (name, fn) => async () => {
    try { await fn(); } catch (e) { log.error(`[scheduler] ${name} failed: ${e.message}`); }
  };
  const tick = guard('sla+escalation', async () => { runSlaChecks(ctx); await runEscalations(ctx); });
  const monitor = guard('monitoring', () => runMonitoring(ctx));
  const timers = [
    setInterval(tick, ctx.config.schedulerSeconds * 1000),
    setInterval(monitor, ctx.config.monitorMinutes * 60000),
  ];
  timers.forEach((t) => t.unref?.());
  // First pass shortly after boot so a fresh start already shows live alerts.
  // Retries because the Python engine may still be starting when the gateway comes up.
  const boot = async (attempt = 1) => {
    try { await runMonitoring(ctx); runSlaChecks(ctx); await runEscalations(ctx); }
    catch (e) {
      if (attempt >= 6) return log.error(`[scheduler] boot monitoring gave up: ${e.message}`);
      setTimeout(() => boot(attempt + 1), 4000).unref?.();
    }
  };
  setTimeout(() => boot(), 500).unref?.();
  return () => timers.forEach(clearInterval);
}

module.exports = { runSlaChecks, runEscalations, runMonitoring, startScheduler };
