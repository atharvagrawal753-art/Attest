'use strict';
const fs = require('node:fs');
const path = require('node:path');

/**
 * Tiny file-backed document store: the whole database is one JSON file, written atomically
 * (temp file + rename) and debounced. Fine for a prototype and for a single gateway process.
 * Everything that touches data goes through this class, so moving to PostgreSQL later means
 * replacing this file, not the business logic.
 */
class Store {
  constructor(dir) {
    this.dir = dir;
    this.uploads = path.join(dir, 'uploads');
    fs.mkdirSync(this.uploads, { recursive: true });
    this.file = path.join(dir, 'db.json');
    this.timer = null;
    this.fresh = !fs.existsSync(this.file);
    this.data = this.fresh
      ? { version: 1, counters: { alert: 0, case: 4900 }, users: [], institutions: [], cases: [], alerts: [], monitoring: null }
      : JSON.parse(fs.readFileSync(this.file, 'utf8'));
  }

  save() {
    if (this.timer) return;
    this.timer = setTimeout(() => { this.timer = null; this.flush(); }, 60);
    this.timer.unref?.();
  }

  flush() {
    if (this.timer) { clearTimeout(this.timer); this.timer = null; }
    const tmp = this.file + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(this.data));
    fs.renameSync(tmp, this.file);
  }

  nextId(kind) {
    this.data.counters[kind] = (this.data.counters[kind] || 0) + 1;
    return this.data.counters[kind];
  }

  writeUpload(sha256, buffer) {
    const file = path.join(this.uploads, sha256);
    if (!fs.existsSync(file)) fs.writeFileSync(file, buffer, { mode: 0o600 });
  }

  readUpload(sha256) {
    if (!/^[a-f0-9]{64}$/.test(sha256)) throw new Error('Invalid upload id');
    return fs.readFileSync(path.join(this.uploads, sha256));
  }
}

module.exports = { Store };
