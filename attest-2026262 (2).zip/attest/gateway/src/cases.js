'use strict';
const crypto = require('node:crypto');
const { AppError } = require('./errors');
const wf = require('./workflow');
const { can } = require('./auth');

const DOC_TYPES = ['application_form', 'faculty_certificate', 'infrastructure_report', 'fire_safety_certificate'];
const CASE_ID = /^AICTE-\d{4}-\d{3,6}$/;
const MAGIC = [[Buffer.from('%PDF'), 'application/pdf'], [Buffer.from([0xff, 0xd8, 0xff]), 'image/jpeg'], [Buffer.from([0x89, 0x50, 0x4e, 0x47]), 'image/png']];
const sha256 = (data) => crypto.createHash('sha256').update(data).digest('hex');
const sniffMime = (buf) => MAGIC.find(([m]) => buf.subarray(0, m.length).equals(m))?.[1] || null;
const shortId = (id) => id.split('-').pop();

const analysisCache = new Map(); // key -> { at, result }
const CACHE_MS = 60000;

function findCase(ctx, id, user) {
  if (!CASE_ID.test(id)) throw new AppError(400, 'BAD_CASE_ID', 'Application number must look like AICTE-2026-4839.');
  const c = ctx.store.data.cases.find((x) => x.id === id);
  // Institutions get a 404 for other institutions' cases, so existence is not leaked.
  if (!c || (user?.role === 'INSTITUTION' && c.institutionId !== user.institutionId)) {
    throw new AppError(404, 'NOT_FOUND', 'No such application.');
  }
  return c;
}

function view(c) {
  return {
    id: c.id, institutionId: c.institutionId, institutionName: c.institutionName, programme: c.programme,
    state: c.state, stateLabel: wf.STATES[c.state].label, stateEnteredAt: c.stateEnteredAt, createdAt: c.createdAt,
    sla: wf.slaStatus(c),
    documents: Object.fromEntries(Object.entries(c.documents).map(([type, d]) => [type, {
      name: d.name, mime: d.mime, sha256: d.sha256, size: d.size, uploadedAt: d.uploadedAt, synthetic: !!d.synthetic }])),
    analysis: c.analysis || null,
    decisions: c.decisions || [],
  };
}

function listFor(ctx, user) {
  const all = ctx.store.data.cases;
  const mine = user.role === 'INSTITUTION' ? all.filter((c) => c.institutionId === user.institutionId) : all;
  return mine.map((c) => ({
    id: c.id, institutionName: c.institutionName, programme: c.programme, state: c.state,
    stateLabel: wf.STATES[c.state].label, stateEnteredAt: c.stateEnteredAt, sla: wf.slaStatus(c),
    score: c.analysis ? c.analysis.score : null,
  }));
}

function createCase(ctx, user, { institutionName, programme }) {
  let inst = user.role === 'INSTITUTION' ? ctx.store.data.institutions.find((i) => i.id === user.institutionId) : null;
  if (!inst) {
    if (user.role === 'INSTITUTION') throw new AppError(403, 'FORBIDDEN', 'Your account is not linked to an institution.');
    inst = { id: `INST-${String(ctx.store.data.institutions.length + 1).padStart(3, '0')}`, name: institutionName, profile: {} };
    ctx.store.data.institutions.push(inst);
  }
  const now = new Date().toISOString();
  const c = {
    id: `AICTE-${new Date().getFullYear()}-${ctx.store.nextId('case')}`,
    institutionId: inst.id, institutionName: inst.name, programme,
    state: 'SUBMITTED', stateEnteredAt: now, createdAt: now, documents: {}, analysis: null, decisions: [],
  };
  ctx.store.data.cases.push(c);
  ctx.store.save();
  ctx.audit.append({ actor: user, action: 'CASE_RECEIVED', caseId: c.id, details: { institution: inst.name, programme } });
  return c;
}

function setState(ctx, c, to, actor, reason) {
  const from = c.state;
  c.state = to;
  c.stateEnteredAt = new Date().toISOString();
  ctx.store.save();
  ctx.audit.append({ actor, action: 'STATE_CHANGED', caseId: c.id, details: { from, to, reason } });
  ctx.alerts.resolveByPrefix(`SLA:${c.id}:`, `Case moved to ${to}`);
}

function addDocument(ctx, c, type, buffer, filename, user) {
  if (!DOC_TYPES.includes(type)) throw new AppError(400, 'BAD_DOCUMENT_TYPE', `Document type must be one of: ${DOC_TYPES.join(', ')}.`);
  if (wf.isTerminal(c.state)) throw new AppError(409, 'CASE_CLOSED', 'This application is closed; documents can no longer be added.');
  if (!Buffer.isBuffer(buffer) || buffer.length === 0) throw new AppError(400, 'EMPTY_BODY', 'Send the file as the request body.');
  const mime = sniffMime(buffer); // judged by content, never by the name or Content-Type header
  if (!mime) throw new AppError(415, 'UNSUPPORTED_FILE', 'Only PDF, JPG and PNG files are accepted.');

  const digest = sha256(buffer);
  ctx.store.writeUpload(digest, buffer);
  const name = String(filename || type).replace(/[^\w.\- ]+/g, '_').slice(0, 80);
  c.documents[type] = { name, mime, sha256: digest, size: buffer.length, uploadedAt: new Date().toISOString(), uploadedBy: user.name };
  c.analysis = null; // stale: the evidence changed
  ctx.store.save();
  ctx.audit.append({ actor: user, action: 'DOCUMENT_UPLOADED', caseId: c.id, details: { type, name, mime, size: buffer.length, sha256: digest } });
  if (c.state === 'CORRECTION_REQUESTED') setState(ctx, c, 'SCRUTINY', user, 'Institution resubmitted documents');
  return c.documents[type];
}

// ---------------------------------------------------------------------------- analysis
function duplicateSignals(ctx, c) {
  const out = [];
  for (const [type, d] of Object.entries(c.documents)) {
    if (d.synthetic) continue;
    const other = ctx.store.data.cases.find((o) => o.id !== c.id && o.institutionId !== c.institutionId
      && Object.values(o.documents).some((x) => x.sha256 === d.sha256));
    if (other) out.push({ code: 'DUPLICATE_DOCUMENT', severity: 'medium', doc: type,
      message: `The identical file was also submitted by another institution (${other.id}).`,
      note: 'A signal for a reviewer to examine; it is not proof of fraud.' });
  }
  return out;
}

async function analyse(ctx, c) {
  const entries = Object.entries(c.documents);
  if (!entries.length) throw new AppError(409, 'NO_DOCUMENTS', 'No documents have been submitted for this application.');
  const key = sha256(entries.map(([t, d]) => `${t}:${d.sha256}`).join('|'));
  let result = analysisCache.get(key);
  if (!result || Date.now() - result.at > CACHE_MS) {
    const documents = entries.map(([type, d]) => (d.synthetic
      ? { type, name: d.name, pages: d.pages }
      : { type, name: d.name, contentBase64: ctx.store.readUpload(d.sha256).toString('base64') }));
    try {
      result = { at: Date.now(), value: await ctx.services.engine.analyze({ caseId: c.id, documents }) };
    } catch (e) {
      if (e.code === 'SERVICE_UNAVAILABLE' && c.analysis) return { ...c.analysis, stale: true };
      throw e;
    }
    analysisCache.set(key, result);
  }
  const value = structuredClone(result.value);
  value.caseId = c.id;
  value.signals = [...(value.signals || []), ...duplicateSignals(ctx, c)];
  return value;
}

function syncAlerts(ctx, c, analysis) {
  for (const r of analysis.rules) {
    const key = `SCRUT:${c.id}:${r.id}`;
    if (r.result === 'Pass') { ctx.alerts.resolveByPrefix(key, 'Rule now passes'); continue; }
    ctx.alerts.raise({
      type: r.result === 'Review' ? 'DATA_CONFLICT' : r.blocking ? 'DOC_MISSING' : 'RULE_FAILED',
      severity: r.blocking ? 'high' : 'medium', message: `${c.id}: ${r.title}. ${r.detail}`,
      caseId: c.id, institutionId: c.institutionId, key,
    });
  }
  for (const s of analysis.signals || []) {
    ctx.alerts.raise({ type: 'AUTH_SIGNAL', severity: s.severity, message: `${c.id}: ${s.message}`,
      caseId: c.id, institutionId: c.institutionId, key: `SIG:${c.id}:${s.code}:${s.doc}` });
  }
}

/** Read-only: same analysis, nothing persisted, no alerts, no audit entry. */
async function preview(ctx, c) {
  return analyse(ctx, c);
}

async function runScrutiny(ctx, c, user) {
  const demoCase = ctx.config.demoMode && c.id === ctx.config.demoCaseId;
  if (wf.isTerminal(c.state) || c.state === 'CORRECTION_REQUESTED') {
    if (!demoCase) {
      throw new AppError(409, 'WRONG_STAGE', c.state === 'CORRECTION_REQUESTED'
        ? 'Awaiting corrections from the institution. Scrutiny resumes when documents are resubmitted.'
        : 'This application is closed.');
    }
    setState(ctx, c, 'SCRUTINY', user, 'Re-opened for demonstration');
  }
  const analysis = await analyse(ctx, c);
  if (c.state === 'SUBMITTED') setState(ctx, c, 'SCRUTINY', user, 'Scrutiny started');
  c.analysis = { ...analysis, runAt: new Date().toISOString(), runBy: { id: user.id, name: user.name } };
  ctx.store.save();
  ctx.audit.append({ actor: user, action: 'SCRUTINY_COMPLETED', caseId: c.id, details: {
    score: analysis.score, summary: analysis.summary, blocking: analysis.blocking.length,
    signals: (analysis.signals || []).length, rulesVersion: analysis.engine?.rulesVersion,
    documents: analysis.documents.map((d) => ({ type: d.type, sha256: d.sha256 })) } });
  syncAlerts(ctx, c, analysis);
  return c.analysis;
}

async function notifyInstitution(ctx, c, subject, body) {
  return ctx.services.escalation.dispatch({
    alertId: `NOTICE-${c.id}`, level: 1, severity: 'low', subject, body,
    recipients: [`INSTITUTION:${c.institutionId}`], channels: ['EMAIL'],
  });
}

async function decide(ctx, c, { decision, reason, override }, user) {
  // Authorisation first: a user who may not take this decision learns nothing about the case's state.
  const needed = wf.DECISIONS[decision]?.permission;
  if (needed && !can(user, needed)) throw new AppError(403, 'FORBIDDEN', 'Your role is not permitted to record this decision.', { required: needed });
  const plan = wf.planDecision(c, decision, { override: !!override, canOverride: can(user, 'override:blocking') });
  if (!plan.ok) throw new AppError(plan.status, plan.code, plan.message);
  if (plan.overrideUsed && reason.length < 15) {
    throw new AppError(400, 'OVERRIDE_NEEDS_REASON', 'An override must be justified in at least 15 characters.');
  }
  const from = c.state;
  c.decisions.push({ decision, reason, by: { id: user.id, name: user.name, role: user.role }, at: new Date().toISOString(), override: plan.overrideUsed });
  setState(ctx, c, plan.to, user, reason);
  ctx.audit.append({ actor: user, action: 'DECISION_RECORDED', caseId: c.id, details: { decision, reason, from, to: plan.to, override: plan.overrideUsed } });
  notifyInstitution(ctx, c, `Application ${c.id}: ${decision}`, reason).catch(() => {});
  return { state: c.state, stateLabel: wf.STATES[c.state].label, override: plan.overrideUsed, message: `${decision} – Application ${shortId(c.id)}` };
}

function forward(ctx, c, user) {
  const plan = wf.planForward(c);
  if (!plan.ok) throw new AppError(plan.status, plan.code, plan.message);
  setState(ctx, c, plan.to, user, 'Forwarded to the Expert Committee');
  return { state: c.state, stateLabel: wf.STATES[c.state].label };
}

module.exports = { DOC_TYPES, CASE_ID, findCase, view, listFor, createCase, addDocument, analyse, preview, runScrutiny,
  decide, forward, setState, shortId, sniffMime, analysisCache };
