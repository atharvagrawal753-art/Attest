'use strict';
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const http = require('node:http');
const { load } = require('../src/config');
const { createContext } = require('../src/context');
const { createApp } = require('../src/app');
const { localEscalation } = require('../src/services');

const fx = JSON.parse(fs.readFileSync(path.join(__dirname, 'fixtures', 'engine-analysis-4839.json'), 'utf8'));
const monitorFx = JSON.parse(fs.readFileSync(path.join(__dirname, 'fixtures', 'engine-monitor.json'), 'utf8'));

/** Stand-ins for the Python and Java services, so gateway logic is tested in isolation. */
function stubServices(state = {}) {
  state.dispatched = [];
  return {
    state,
    engine: {
      async analyze({ documents }) {
        if (state.engineDown) { const { AppError } = require('../src/errors'); throw new AppError(503, 'SERVICE_UNAVAILABLE', 'engine down'); }
        return structuredClone(documents.some((d) => d.type === 'fire_safety_certificate') ? fx.withNoc : fx.base);
      },
      async monitor() { return structuredClone(monitorFx); },
    },
    escalation: {
      async evaluate(sev, age) { return localEscalation(sev, age); },
      async dispatch(m) { state.dispatched.push(m); return { dispatched: true }; },
    },
    async status() { return {}; },
  };
}

async function startApp(extraEnv = {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'attest-test-'));
  const config = load({ NODE_ENV: 'test', DATA_DIR: dir, DEMO_MODE: 'true', SEED_DEMO_USERS: 'true', DEV_PASSWORD: 'Test@12345',
    RATE_LIMIT_PER_MIN: '5000', INTERNAL_KEY: 'test-key', ...extraEnv });
  const services = stubServices();
  const ctx = createContext(config, { services });
  const server = http.createServer(createApp(ctx));
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${server.address().port}`;

  async function req(method, url, { token, body, raw, headers = {} } = {}) {
    const h = { ...headers };
    if (token) h.Authorization = `Bearer ${token}`;
    if (body !== undefined) h['Content-Type'] = 'application/json';
    const res = await fetch(base + url, { method, headers: h, body: raw !== undefined ? raw : body !== undefined ? JSON.stringify(body) : undefined });
    const text = await res.text();
    let json = null; try { json = JSON.parse(text); } catch { /* not json */ }
    return { status: res.status, json, headers: res.headers };
  }
  const login = async (username, password = 'Test@12345') => (await req('POST', '/api/auth/login', { body: { username, password } })).json?.token;
  const close = () => new Promise((r) => { ctx.store.flush(); server.close(r); });
  return { ctx, services, base, req, login, close, dir };
}

module.exports = { startApp, stubServices, fx };
