'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const wf = require('../src/workflow');
const { AuditLog } = require('../src/audit');
const auth = require('../src/auth');
const { localEscalation } = require('../src/services');

const caseAt = (state, over = {}) => ({ id: 'AICTE-2026-1', state, stateEnteredAt: new Date().toISOString(), analysis: { blocking: [] }, ...over });

test('workflow: no decision without a scrutiny report', () => {
  const r = wf.planDecision(caseAt('SCRUTINY', { analysis: null }), 'Approved');
  assert.equal(r.code, 'NO_ANALYSIS');
});

test('workflow: decisions are not allowed before scrutiny starts or after closure', () => {
  assert.equal(wf.planDecision(caseAt('SUBMITTED'), 'Rejected').code, 'WRONG_STAGE');
  assert.equal(wf.planDecision(caseAt('APPROVED'), 'Rejected').code, 'CASE_CLOSED');
});

test('workflow: compliance gate blocks approval, override needs permission', () => {
  const blocked = caseAt('SCRUTINY', { analysis: { blocking: [{ reason: 'Not attached: Fire safety certificate.' }] } });
  assert.equal(wf.planDecision(blocked, 'Approved').code, 'COMPLIANCE_GATE');
  assert.equal(wf.planDecision(blocked, 'Approved', { override: true, canOverride: false }).code, 'OVERRIDE_NOT_PERMITTED');
  const ok = wf.planDecision(blocked, 'Approved', { override: true, canOverride: true });
  assert.deepEqual([ok.ok, ok.to, ok.overrideUsed], [true, 'APPROVED', true]);
  assert.equal(wf.planDecision(blocked, 'Correction requested').ok, true); // other decisions are not gated
});

test('workflow: forwarding needs a clean report', () => {
  assert.equal(wf.planForward(caseAt('SCRUTINY')).to, 'EXPERT_REVIEW');
  assert.equal(wf.planForward(caseAt('SCRUTINY', { analysis: { blocking: [{}] } })).code, 'COMPLIANCE_GATE');
  assert.equal(wf.planForward(caseAt('EXPERT_REVIEW')).code, 'WRONG_STAGE');
});

test('workflow: SLA ratio and public status expose nothing sensitive', () => {
  const c = caseAt('SCRUTINY', { stateEnteredAt: new Date(Date.now() - 9 * wf.DAY_MS).toISOString(), institutionName: 'X', analysis: { score: 10 } });
  assert.ok(wf.slaStatus(c).ratio > 1.2);
  assert.deepEqual(Object.keys(wf.publicStatus(c)).sort(),
    ['expectedBy', 'institution', 'lastUpdated', 'outcome', 'reference', 'stage', 'stageLabel']);
});

test('audit: hash chain verifies, and any edit, deletion or reorder is detected', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'audit-'));
  const log = new AuditLog(dir);
  for (let i = 0; i < 5; i++) log.append({ action: 'X', details: { i } });
  assert.equal(log.verify().valid, true);
  const file = path.join(dir, 'audit.jsonl');
  const original = fs.readFileSync(file, 'utf8');

  fs.writeFileSync(file, original.replace('"i":2', '"i":9'));
  assert.deepEqual([log.verify().valid, log.verify().brokenAtSeq, log.verify().reason], [false, 3, 'entry content altered']);

  const lines = original.trim().split('\n');
  fs.writeFileSync(file, [lines[0], lines[2], lines[3], lines[4]].join('\n') + '\n');
  assert.equal(log.verify().valid, false);
  fs.writeFileSync(file, [lines[0], lines[2], lines[1], lines[3], lines[4]].join('\n') + '\n');
  assert.equal(log.verify().valid, false);
  fs.writeFileSync(file, original);
  assert.equal(log.verify().valid, true);
});

test('auth: scrypt hashes verify, differ per salt, and reject wrong passwords', () => {
  const a = auth.hashPassword('S3cret!pass'), b = auth.hashPassword('S3cret!pass');
  assert.notEqual(a, b);
  assert.equal(auth.verifyPassword('S3cret!pass', a), true);
  assert.equal(auth.verifyPassword('wrong', a), false);
  assert.equal(auth.verifyPassword('x', 'garbage'), false);
});

test('auth: account locks after 5 failures', () => {
  const g = new auth.LoginGuard();
  for (let i = 0; i < 5; i++) g.failure('u');
  assert.throws(() => g.check('u'), (e) => e.code === 'ACCOUNT_LOCKED');
  assert.doesNotThrow(() => g.check('u', Date.now() + 16 * 60000));
});

test('auth: roles hold the intended permissions', () => {
  const u = (role) => ({ role });
  assert.equal(auth.can(u('INSTITUTION'), 'decision:approve'), false);
  assert.equal(auth.can(u('SCRUTINY_OFFICER'), 'decision:approve'), false);
  assert.equal(auth.can(u('EXPERT_COMMITTEE'), 'override:blocking'), false);
  assert.equal(auth.can(u('REGIONAL_OFFICER'), 'override:blocking'), true);
  assert.equal(auth.can(u('ADMIN'), 'anything'), true);
});

test('escalation fallback matches the Java matrix', () => {
  const cases = [['critical', 0, 1], ['critical', 30, 2], ['critical', 120, 3], ['high', 239, 1], ['high', 240, 2], ['high', 2880, 3],
    ['medium', 1439, 1], ['medium', 1440, 2], ['medium', 4320, 3], ['low', 4319, 1], ['low', 4320, 2], ['low', 999999, 2]];
  for (const [sev, age, level] of cases) assert.equal(localEscalation(sev, age).level, level, `${sev}@${age}`);
});
