'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { startApp } = require('./helpers');
const jobs = require('../src/jobs');

const DEMO = 'AICTE-2026-4839';
const pdf = Buffer.from('%PDF-1.4\n1 0 obj<<>>endobj\n%%EOF');

test('authentication, RBAC and institution isolation', async (t) => {
  const app = await startApp();
  t.after(app.close);
  const { req, login } = app;

  assert.equal((await req('GET', '/api/cases')).status, 401);
  assert.equal((await req('POST', '/api/auth/login', { body: { username: 'admin', password: 'nope' } })).status, 401);
  assert.equal((await req('GET', '/api/cases', { token: 'garbage' })).status, 401);

  const inst = await login('sample.institution');
  const list = await req('GET', '/api/cases', { token: inst });
  assert.deepEqual(list.json.items.map((c) => c.id), [DEMO]);                         // only its own
  assert.equal((await req('GET', '/api/cases/AICTE-2026-4701', { token: inst })).status, 404); // others: not even revealed
  assert.equal((await req('POST', `/api/cases/${DEMO}/scrutiny`, { token: inst })).status, 403);
  assert.equal((await req('GET', '/api/alerts', { token: inst })).status, 403);

  const scrutiny = await login('scrutiny.officer');
  await req('POST', `/api/cases/${DEMO}/scrutiny`, { token: scrutiny });
  const d = await req('POST', `/api/cases/${DEMO}/decision`, { token: scrutiny, body: { decision: 'Approved', reason: 'trying anyway' } });
  assert.equal(d.status, 403); // scrutiny officers may not approve
  assert.equal((await req('GET', '/api/audit/verify', { token: await login('regional.officer') })).json.valid, true);
});

test('login lockout after repeated failures', async (t) => {
  const app = await startApp();
  t.after(app.close);
  for (let i = 0; i < 5; i++) await app.req('POST', '/api/auth/login', { body: { username: 'admin', password: 'bad' } });
  const locked = await app.req('POST', '/api/auth/login', { body: { username: 'admin', password: 'Test@12345' } });
  assert.equal(locked.status, 429);
  assert.equal(locked.json.error.code, 'ACCOUNT_LOCKED');
});

test('demo session can be disabled', async (t) => {
  const on = await startApp();
  const off = await startApp({ DEMO_MODE: 'false' });
  t.after(async () => { await on.close(); await off.close(); });
  assert.equal((await on.req('POST', '/api/session/demo')).status, 200);
  assert.equal((await off.req('POST', '/api/session/demo')).status, 404);
});

test('scrutiny -> compliance gate -> upload -> approval, fully audited', async (t) => {
  const app = await startApp();
  t.after(app.close);
  const { req, ctx, services } = app;
  const officer = await app.login('regional.officer');
  const url = (p) => `/api/cases/${DEMO}${p}`;

  assert.equal((await req('POST', url('/decision'), { token: officer, body: { decision: 'Approved', reason: 'too early' } })).json.error.code, 'NO_ANALYSIS');

  const run = await req('POST', url('/scrutiny'), { token: officer });
  assert.equal(run.status, 200);
  assert.equal(run.json.score, 72);
  assert.equal(run.json.state, 'SCRUTINY');
  assert.deepEqual(ctx.alerts.list({ caseId: DEMO, status: 'active' }).map((a) => a.type).sort(), ['DATA_CONFLICT', 'DOC_MISSING']);

  const gate = await req('POST', url('/decision'), { token: officer, body: { decision: 'Approved', reason: 'looks fine' } });
  assert.equal(gate.status, 409);
  assert.equal(gate.json.error.code, 'COMPLIANCE_GATE');

  const bad = await req('PUT', url('/documents/fire_safety_certificate'), { token: officer, raw: Buffer.from('MZ not a pdf'), headers: { 'Content-Type': 'application/pdf' } });
  assert.equal(bad.status, 415);
  assert.equal((await req('PUT', url('/documents/passport'), { token: officer, raw: pdf })).status, 400);
  const up = await req('PUT', url('/documents/fire_safety_certificate?filename=noc.pdf'), { token: officer, raw: pdf, headers: { 'Content-Type': 'application/pdf' } });
  assert.equal(up.status, 201);
  assert.equal(up.json.sha256.length, 64);
  assert.equal((await req('GET', url(''), { token: officer })).json.analysis, null); // old report is stale

  const rerun = await req('POST', url('/scrutiny'), { token: officer });
  assert.equal(rerun.json.blocking.length, 0);
  assert.equal(rerun.json.score, 92);
  assert.ok(!ctx.alerts.list({ caseId: DEMO, status: 'active' }).some((a) => a.type === 'DOC_MISSING')); // alert auto-resolved

  const ok = await req('POST', url('/decision'), { token: officer, body: { decision: 'Approved', reason: 'All mandatory documents attached' } });
  assert.equal(ok.status, 200);
  assert.equal(ok.json.state, 'APPROVED');
  assert.equal(ok.json.message, 'Approved – Application 4839');
  assert.equal((await req('POST', url('/decision'), { token: officer, body: { decision: 'Rejected', reason: 'second thoughts' } })).json.error.code, 'CASE_CLOSED');
  assert.equal(services.state.dispatched.at(-1).recipients[0], 'INSTITUTION:INST-001'); // institution was notified

  const trail = (await req('GET', url('/audit?limit=100'), { token: officer })).json.items.map((e) => e.action);
  for (const a of ['CASE_RECEIVED', 'SCRUTINY_COMPLETED', 'DOCUMENT_UPLOADED', 'DECISION_RECORDED']) assert.ok(trail.includes(a), a);
  assert.equal((await req('GET', '/api/audit/verify', { token: officer })).json.valid, true);
});

test('override needs authority and a real justification', async (t) => {
  const app = await startApp();
  t.after(app.close);
  const { req, login } = app;
  const regional = await login('regional.officer'), expert = await login('expert.member');
  await req('POST', `/api/cases/${DEMO}/scrutiny`, { token: regional });
  const post = (token, body) => req('POST', `/api/cases/${DEMO}/decision`, { token, body });
  assert.equal((await post(expert, { decision: 'Approved', reason: 'override please', override: true })).status, 403);
  assert.equal((await post(regional, { decision: 'Approved', reason: 'short', override: true })).json.error.code, 'OVERRIDE_NEEDS_REASON');
  const ok = await post(regional, { decision: 'Approved', reason: 'Certificate in transit; inspected on site on 12 Nov', override: true });
  assert.equal(ok.json.override, true);
});

test('demo case can be re-run after a decision (demo mode only)', async (t) => {
  const app = await startApp();
  t.after(app.close);
  const token = await app.login('regional.officer');
  await app.req('POST', `/api/cases/${DEMO}/scrutiny`, { token });
  await app.req('POST', `/api/cases/${DEMO}/decision`, { token, body: { decision: 'Rejected', reason: 'Not eligible' } });
  const again = await app.req('POST', `/api/cases/${DEMO}/scrutiny`, { token });
  assert.equal(again.json.state, 'SCRUTINY');
});

test('uploads: size limit, and other institutions cannot upload to a case', async (t) => {
  const app = await startApp({ MAX_UPLOAD_MB: '1' });
  t.after(app.close);
  const token = await app.login('sample.institution');
  const big = Buffer.concat([pdf, Buffer.alloc(1.2 * 1024 * 1024)]);
  assert.equal((await app.req('PUT', `/api/cases/${DEMO}/documents/application_form`, { token, raw: big })).status, 413);
  assert.equal((await app.req('PUT', '/api/cases/AICTE-2026-4701/documents/application_form', { token, raw: pdf })).status, 404);
});

test('SLA breaches raise alerts and unattended alerts escalate', async (t) => {
  const app = await startApp();
  t.after(app.close);
  const { ctx, services } = app;
  jobs.runSlaChecks(ctx);
  const sla = ctx.alerts.list({ caseId: 'AICTE-2026-4701', status: 'active' });
  assert.equal(sla.length, 1);
  assert.equal(sla[0].type, 'SLA_BREACH');
  assert.equal(ctx.alerts.list({ caseId: 'AICTE-2026-4755', status: 'active' })[0].type, 'SLA_WARNING');
  assert.equal(ctx.alerts.list({ caseId: 'AICTE-2026-4620' }).length, 0); // approved cases have no SLA

  assert.ok(await jobs.runEscalations(ctx) >= 2);
  assert.equal(ctx.alerts.all.find((a) => a.type === 'SLA_BREACH').level, 3); // breached ~2 days ago, severity high
  assert.ok(services.state.dispatched.length >= 2);
  assert.equal(await jobs.runEscalations(ctx), 0); // idempotent

  const breach = ctx.alerts.all.find((a) => a.type === 'SLA_BREACH');
  const officer = await app.login('scrutiny.officer');
  assert.equal((await app.req('POST', `/api/alerts/${breach.id}/ack`, { token: officer })).json.status, 'acknowledged');
});

test('monitoring raises, de-duplicates and resolves alerts', async (t) => {
  const app = await startApp();
  t.after(app.close);
  const first = await jobs.runMonitoring(app.ctx);
  assert.equal(first.raised, 1);
  assert.equal((await jobs.runMonitoring(app.ctx)).raised, 0); // same finding is not raised twice
  assert.equal(app.ctx.alerts.list({ status: 'active' })[0].type, 'COMPLIANCE_WARNING');
  const dash = await app.req('GET', '/api/dashboard', { token: await app.login('regional.officer') });
  assert.equal(dash.json.alerts.active, 1);
});

test('live alert stream: one-use ticket', async (t) => {
  const app = await startApp();
  t.after(app.close);
  const token = await app.login('regional.officer');
  const { ticket } = (await app.req('POST', '/api/stream-ticket', { token })).json;
  const ac = new AbortController();
  const res = await fetch(`${app.base}/api/alerts/stream?ticket=${ticket}`, { signal: ac.signal });
  assert.equal(res.status, 200);
  assert.match(res.headers.get('content-type'), /text\/event-stream/);
  app.ctx.alerts.raise({ type: 'T', severity: 'low', message: 'hello stream', key: 'T:1' });
  const reader = res.body.getReader();
  let text = '';
  while (!text.includes('hello stream')) text += Buffer.from((await reader.read()).value).toString();
  assert.match(text, /event: alert/);
  ac.abort();
  assert.equal((await fetch(`${app.base}/api/alerts/stream?ticket=${ticket}`)).status, 401); // ticket already used
});

test('internal portal endpoint requires the key and hides sensitive fields', async (t) => {
  const app = await startApp();
  t.after(app.close);
  assert.equal((await app.req('GET', `/internal/public/applications/${DEMO}`)).status, 401);
  const ok = await app.req('GET', `/internal/public/applications/${DEMO}`, { headers: { 'X-Internal-Key': 'test-key' } });
  assert.equal(ok.status, 200);
  assert.ok(!('analysis' in ok.json) && !('score' in ok.json));
  assert.equal((await app.req('GET', '/internal/public/applications/AICTE-2026-1', { headers: { 'X-Internal-Key': 'test-key' } })).status, 404);
});

test('security headers, no stack traces, bad input handled', async (t) => {
  const app = await startApp();
  t.after(app.close);
  const page = await app.req('GET', '/');
  assert.equal(page.status, 200);
  assert.ok(page.headers.get('content-security-policy').includes("frame-ancestors 'none'"));
  assert.equal(page.headers.get('x-content-type-options'), 'nosniff');
  assert.equal(page.headers.get('x-powered-by'), null);
  const bad = await app.req('POST', '/api/auth/login', { raw: '{not json', headers: { 'Content-Type': 'application/json' } });
  assert.equal(bad.status, 400);
  assert.equal(bad.json.error.code, 'BAD_JSON');
  assert.equal((await app.req('GET', '/api/nope')).status, 401); // unknown API paths reveal nothing without a session
  assert.equal((await app.req('GET', '/api/nope', { token: await app.login('admin') })).status, 404);
  const traversal = await fetch(app.base + '/..%2f..%2fpackage.json');
  assert.ok(!(await traversal.text()).includes('attest-gateway'), 'path traversal must not expose files');
});

test('tampering with the audit file is reported by the API', async (t) => {
  const app = await startApp();
  t.after(app.close);
  const token = await app.login('admin');
  const file = path.join(app.dir, 'audit.jsonl');
  fs.writeFileSync(file, fs.readFileSync(file, 'utf8').replace('Synthetic demonstration data', 'edited by an attacker'));
  const v = (await app.req('GET', '/api/audit/verify', { token })).json;
  assert.equal(v.valid, false);
  assert.equal(v.reason, 'entry content altered');
});
